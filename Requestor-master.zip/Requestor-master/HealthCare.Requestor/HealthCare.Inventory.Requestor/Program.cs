﻿using Microsoft.Extensions.Logging;
using System;
using System.Threading.Tasks;

namespace HealthCare.Inventory.Requestor
{
    public class Program
    {
        static async Task Main(string[] args)
        {

            var settings = Bootstrapper
                    .GetSettings(args)
                    .Verify();

            var services = settings.GetServices();

            try
            {
                await new RequestorApplication(services)
                    .DespatchRefreshRequests();
            }
            catch (Exception ex)
            {
                services.Logger.LogError(ex, "HealthCare.Inventory.RequestorException - Main");
            }
        }
    }
}
