﻿using Amazon;
using Amazon.DynamoDBv2;
using Amazon.DynamoDBv2.DataModel;
using Amazon.Extensions.NETCore.Setup;
using Amazon.Runtime;
using Amazon.SQS;
using HealthCare.Inventory.RefreshQueue;
using HealthCare.Inventory.Requestor.Core.DynamoDB;
using HealthCare.Inventory.Requestor.DynamoDB;
using HealthCare.Inventory.Requestor.RefreshStrategy;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Serilog;
using Serilog.Formatting.Compact;
using System;
using System.Linq;
using System.Net.Http;

namespace HealthCare.Inventory.Requestor
{
    public static class Bootstrapper
    {
        public static AppSettings GetSettings(params string[] args)
        {
            return new ConfigurationBuilder()
                .SetBasePath(AppDomain.CurrentDomain.BaseDirectory)
                .AddJsonFile("appsettings.json", optional: true, reloadOnChange: true)
                .AddJsonFile("appsettings.{env.EnvironmentName}.json", optional: true, reloadOnChange: true)
                .AddEnvironmentVariables()
                .AddCommandLine(args)
                .Build()
                .Get<AppSettings>();
        }

        public static AppServices GetServices(this AppSettings settings)
        {
            Log.Logger = new LoggerConfiguration()
                .MinimumLevel.Debug()
                .WriteTo.RollingFile(pathFormat: "InventoryManager.Requestor-.log", formatter: new CompactJsonFormatter(), fileSizeLimitBytes: 1000000)
                .WriteTo.Console(formatter: new CompactJsonFormatter())
                .CreateLogger()
                .ForContext("application_name", "HealthCare.Inventory.Requestor");
            var refreshQueue = settings.RefreshQueue;
           // var credentials = new BasicAWSCredentials(accessKey, secretKey);

            var serviceCollection = new ServiceCollection()
                .AddLogging(b => b.AddSerilog())
                .AddDefaultAWSOptions(GetAwsOptions(settings))
                .AddAWSService<IAmazonDynamoDB>()
                .AddTransient<IDynamoDBContext, DynamoDBContext>()
                //.AddSingleton<IDynamoDBContext, DynamoDBContext>(p => new DynamoDBContext(new AmazonDynamoDBClient())) 
                .AddTransient<IDynamoDbStrategyService>(
                x => new DynamoDbStrategyService(x.GetService<IDynamoDBContext>(), settings.DynamoDbBatchSize, x.GetService<ILogger<Program>>()))
                .AddTransient<IRefreshStrategy, DoNotUpdateStrategy>()
                .AddTransient<IRefreshStrategy>(x => new EveryMinuteStrategy());

            return Resolve(serviceCollection, settings);
        }

        private static AppServices Resolve(IServiceCollection serviceCollection, AppSettings settings)
        {
            var serviceProvider = serviceCollection.BuildServiceProvider();

            var refreshStrategies = serviceProvider
                .GetServices<IRefreshStrategy>()
                .ToList();

            var logger = serviceProvider
                .GetRequiredService<ILogger<Program>>();

            var dynamoDb = new DynamoDbDatabase(serviceProvider.GetRequiredService<IDynamoDbStrategyService>(), logger);

            var refreshQueue = settings.RefreshQueue;

            var amazonSqsClient = refreshQueue.UseAwsExecutionRole ?
                new AmazonSQSClient() :
                new AmazonSQSClient(
                    refreshQueue.AccessKeyId,
                    refreshQueue.SecretKey,
                    RegionEndpoint.GetBySystemName(refreshQueue.RegionName));

            return new AppServices
            {
                Logger = logger,

                IncomingQueue = new SqsRefreshQueue(
                    refreshQueue.Url,
                    serviceProvider.GetRequiredService<ILogger<SqsRefreshQueue>>(),
                    amazonSqsClient
                ),
                RefreshStrategies = refreshStrategies,
                DynmoDbDatabase = dynamoDb,
            };
        }
        private static RegionEndpoint GetAwsEndpointByName(string name)
        {
            // default to Virginia.
            var defaultRegionEndpoint = RegionEndpoint.USEast1;
            if (string.IsNullOrWhiteSpace(name)) return defaultRegionEndpoint;

            // fetch the RegionEndpoint by the system name (eg us-east-1 or us-west-2).
            RegionEndpoint regionEndpoint = null;
            try
            {
                regionEndpoint = RegionEndpoint.GetBySystemName(name);
            }
            catch (Exception)
            {
                //TODO: Exeption handling
            }
            return regionEndpoint ?? defaultRegionEndpoint;
        }
        private static AWSOptions GetAwsOptions(AppSettings settings)
        {
            return new AWSOptions()
            {
                Region = GetAwsEndpointByName(settings.RefreshQueue.RegionName),
                Credentials = new BasicAWSCredentials(settings.RefreshQueue.AccessKeyId, settings.RefreshQueue.SecretKey)
            };
        }
    }
}
