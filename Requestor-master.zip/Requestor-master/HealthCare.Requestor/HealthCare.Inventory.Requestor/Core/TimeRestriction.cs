﻿using System;

namespace HealthCare.Inventory.Requestor
{
    public class TimeRestriction
    {
        TimeSpan startTime;
        TimeSpan endTime;
        public TimeRestriction(string start = "22:00", string end = "11:00")
        {
            startTime = GetTime(start);
            endTime = GetTime(end);
        }

        public bool WithinRestrictedHours(DateTime dateTime)
        {
            if (startTime <= endTime)
            {
                return (dateTime.TimeOfDay >= startTime
                    && dateTime.TimeOfDay <= endTime);
            }
            else
            {
                return (startTime <= dateTime.TimeOfDay
                    || dateTime.TimeOfDay <= endTime);
            }
        }

        private TimeSpan GetTime(string value)
        {
            if (!TimeSpan.TryParse(value, out TimeSpan time))
            {
                throw new InvalidCastException("Invalid.Value should be in HH:mm format.");
            }
            return time;
        }
    }
}

