﻿using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Text;

namespace HealthCare.InventoryLoader
{
    public class AppLogger
    {
        public ILogger Logger { get; set; }

        public string Prefix { get; set; }

        public AppLogger(ILogger logger)
        {
            Logger = logger;            
        }

        public AppLogger(ILogger logger, string pwid, string startDate, string endDate)
        {
            Logger = logger;
            Prefix = GetPrefix(
                pwid: pwid,
                startDate: startDate, 
                endDate: endDate);
        }

        public void SetPrefix(string pwid, string startDate, string endDate)
        {
            Prefix = GetPrefix(
                pwid: pwid,
                startDate: startDate,
                endDate: endDate);
        }

        public void ClearPrefix()
        {
            Prefix = string.Empty;
        }

        public virtual void Write(string msg)
        {
            if (Logger != null)
                Logger.LogInformation($"{Prefix} {msg}");
        }

        public virtual void WriteError(Exception ex, string msg)
        {
            if (Logger != null)
                Logger.LogError(ex, $"{msg} - {Prefix} Error occured");
            
        }

        public virtual string GetPrefix(string pwid, string startDate, string endDate)
        {
            return
                $"{pwid} " +
                (string.IsNullOrWhiteSpace(startDate) ? "" : $"{DateTime.Parse(startDate).ToString("M/d")} ") +
                (string.IsNullOrWhiteSpace(endDate) ? "" : $"to {DateTime.Parse(endDate).ToString("M/d")} :");
        }
    }
}
