﻿using HealthCare.Inventory.RefreshQueue;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using HealthCare.Inventory.Requestor;
namespace HealthCare.Inventory.Requestor
{
    public class RequestorApplication
    {
        readonly ILogger Logger;
        readonly IRefreshQueue outgoingQueue;
        readonly IList<IRefreshStrategy> refreshStrategies;
        readonly IDatabase db;

        public RequestorApplication(AppServices services)
        {
            Logger = services.Logger;
            db = services.DynmoDbDatabase;
            outgoingQueue = services.IncomingQueue;
            refreshStrategies = services.RefreshStrategies;
        }

        public async Task DespatchRefreshRequests()
        {
            var providerStrategies = await db.GetExpiredStrategies(DateTime.UtcNow);
            //var refreshRequestMessages = providerStrategies.ForEach(x => x.i)
            var refreshRequestMessages = providerStrategies.Select(x =>
            new RefreshRequestMessage
            {
                Id = x.Id,
                Pwid = x.ProviderId,
                PartnerCode = x.PartnerCode,
                StartDate = DateTime.UtcNow.AddDays(Convert.ToDouble(x.StartOffset)).ToString("MM/dd/yyyy hh:mm:ss tt"),
                EndDate = DateTime.UtcNow.AddDays(Convert.ToDouble(x.EndOffset)).ToString("MM/dd/yyyy hh:mm:ss tt")
            }).ToList();

            await SendRefreshRequests(refreshRequestMessages);
            await UpdateStrategySyncStatus(providerStrategies);
        }

        public virtual IList<ProviderStrategyWithPartnerInfo> GetExpiredInventory(
            IList<ProviderStrategyWithPartnerInfo> providerStrategies)
        {
            var allRequests = new List<ProviderStrategyWithPartnerInfo>();
            foreach (var strategy in refreshStrategies)
            {
                var providerRequests = strategy
                    .GetProvidersToUpdate(providerStrategies);

                if (providerRequests.IsEmpty())
                    continue;

                allRequests.AddRange(providerRequests);
                Write($"For {strategy.Name}, {providerRequests.Count} provider-strategies are in need of updating");
            }

            return allRequests;
        }

        public virtual async Task<bool> SendRefreshRequests(IList<RefreshRequestMessage> SendRefreshRequests)
        {
            outgoingQueue.Send(SendRefreshRequests);
            Write($"{SendRefreshRequests.Count} messages sent.");
            return true;
        }

        public virtual async Task<bool> UpdateStrategySyncStatus(List<ProviderRefreshStrategy> allProviders)
        {
            Write("Updating database with all supported providers from Solr - started");
            await db.SyncProviders(allProviders);
            Write("Updating database with all supported providers from Solr - completed");

            return true;
        }

        public virtual void Write(string msg)
        {
            if (Logger != null)
                Logger.LogInformation(msg);
        }
    }
}
