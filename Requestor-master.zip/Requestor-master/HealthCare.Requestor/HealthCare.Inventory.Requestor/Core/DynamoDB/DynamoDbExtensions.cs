﻿using HealthCare.Inventory.Requestor;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;

namespace HealthCare.Inventory.Requestor.DynamoDB
{
    public static class DynamoDbExtensions
    {
        #region public methods
        //public static List<DynamoDbInventory> ToInventory(this TimeSlot timeSlot, DateTime createdOn, IList<AppointmentReason> appointmentReasons)
        //{
        //    List<DynamoDbInventory> dynamoDBInventoryData = new List<DynamoDbInventory>();
        //    if (timeSlot.PartnerReasonIds != null && timeSlot.PartnerReasonIds.Length > 0)
        //    {
        //        foreach (var reasonId in timeSlot.PartnerReasonIds)
        //        {
        //            var appointmentReason = appointmentReasons
        //                .FirstOrDefault(x => x.ReasonId == reasonId);
        //            var inventory = GetDynamoDbInventory(timeSlot, appointmentReason);
        //            dynamoDBInventoryData.Add(inventory);
        //        }
        //    }
        //    else
        //    {
        //        var inventory = GetDynamoDbInventory(timeSlot);
        //        dynamoDBInventoryData.Add(inventory);
        //    }

        //    return dynamoDBInventoryData;
        //}

        public static IEnumerable<List<T>> SplitList<T>(this List<T> items, int nSize)
        {
            for (int i = 0; i < items.Count; i += nSize)
            {
                yield return items.GetRange(i, Math.Min(nSize, items.Count - i));
            }
        }
        #endregion

        #region private methods
        //private static DynamoDbInventory GetDynamoDbInventory(TimeSlot timeSlot, AppointmentReason appointmentReason = null)
        //{
        //    var apptCategory = timeSlot.AppointmentCategory;
        //    var concatReason = appointmentReason == null ? string.Empty
        //        : $"{appointmentReason?.ReasonId}_{appointmentReason?.ReasonCode}_{appointmentReason?.Reason}";
        //    var inventoryId = GetInventoryId(timeSlot, apptCategory, concatReason);

        //    var dynamoDBInventory = new DynamoDbInventory()
        //    {
        //        InventoryId = inventoryId,
        //        Pwid = timeSlot.Pwid,
        //        AppointmentDateTime = timeSlot.Time.ToString("yyyy-MM-dd'T'HH:mm:ss.fffK", CultureInfo.InvariantCulture),
        //        //AppointmentDateTimeUtc = item.AppointmentDateTimeUtc != null 
        //        //    ? Convert.ToDateTime(item.AppointmentDateTimeUtc).ToString("yyyy-MM-dd'T'HH:mm:ss.fffK", CultureInfo.InvariantCulture) 
        //        //    : string.Empty,
        //    };

        //    return dynamoDBInventory;
        //}

        //private static string GetInventoryId(TimeSlot timeSlot, string apptCategory, string concatReason)
        //{
        //    return $"{timeSlot.Pwid}_{timeSlot.PartnerId}_{timeSlot.OfficeId}_{timeSlot.PartnerProviderId}" +
        //           $"_{timeSlot.PartnerSiteId}_{timeSlot.PartnerPracticeId}_{timeSlot.Id}_{timeSlot.Length}" +
        //           $"_{timeSlot.Type}_{apptCategory}_{timeSlot.Time.ToString("yyyy-MM-ddTHH:mm")}_{concatReason}";
        //}
        #endregion
    }
}
