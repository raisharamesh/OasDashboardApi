﻿using HealthCare.Inventory.RefreshQueue;
using HealthCare.Inventory.Requestor;
using HealthCare.Inventory.Requestor.Core.DynamoDB;
using HealthCare.InventoryLoader;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Threading.Tasks;

namespace HealthCare.Inventory.Requestor.DynamoDB
{
    public class DynamoDbDatabase : IDatabase
    {
        private IDynamoDbStrategyService _dynamoDbStrategyService;

        public AppLogger Logger { get; set; }

        public DynamoDbDatabase(IDynamoDbStrategyService dynamoDbStrategyService, ILogger logger = null)
        {
            _dynamoDbStrategyService = dynamoDbStrategyService;

            if (logger != null)
                Logger = new AppLogger(logger);
        }

        //public async Task<bool> Update(List<ProviderRefreshStrategy> inventoryList)
        //{
        //    await LogTime(
        //        "Upsert Inventory",
        //        () => _dynamoDbInventoryService.Upsert(inventoryList)
        //    );

        //    return true;
        //}

        private async Task<bool> LogTime(string methodDescription, Func<Task<bool>> method)
        {
            var stopWatch = new Stopwatch();
            stopWatch.Start();

            await method();

            stopWatch.Stop();
            Write($"Execution took {stopWatch.ElapsedMilliseconds} ms: {methodDescription}");

            return true;
        }

        protected virtual void Write(string msg)
        {
            Logger?.Write(msg);
        }

        public Task<IList<ProviderRefreshStrategy>> GetProviderStrategy(DateTime dateTime)
        {
            throw new NotImplementedException();
        }

        public Task<IList<string>> GetActivePartners()
        {
            throw new NotImplementedException();
        }

        public Task<bool> ChangeLastUpdate(IList<ProviderStrategyWithPartnerInfo> strategiestoUpdate)
        {
            throw new NotImplementedException();
        }

        public Task<List<string>> GetNewProviders(IEnumerable<PartnerProvider> allProviders)
        {
            throw new NotImplementedException();
        }

        public async Task<bool> SyncProviders(List<ProviderRefreshStrategy> providers)
        {
            var strategies = await _dynamoDbStrategyService.Update(providers);
            return strategies;
        }

        public Task<bool> AddDefaultStrategies(List<string> pwids)
        {
            throw new NotImplementedException();
        }

        public async Task<List<ProviderRefreshStrategy>> GetExpiredStrategies(DateTime dateTime)
        {
            var strategies = await _dynamoDbStrategyService.GetExpiredStrategies(dateTime);
            return strategies;
        }
    }
}
