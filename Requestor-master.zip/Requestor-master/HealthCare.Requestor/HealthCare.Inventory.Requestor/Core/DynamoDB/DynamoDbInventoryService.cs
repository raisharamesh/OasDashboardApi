﻿using Amazon.DynamoDBv2.DataModel;
using Amazon.DynamoDBv2.DocumentModel;
using HealthCare.Inventory.Requestor;
using HealthCare.Inventory.Requestor.Queue;
using Microsoft.Extensions.Logging;
using Serilog.Context;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Threading.Tasks;

namespace HealthCare.Inventory.Requestor.DynamoDB
{
    public interface IDynamoDbStrategyService
    {
        async Task<bool> Update(List<ProviderRefreshStrategy> inventoryList);
        async Task<List<ProviderRefreshStrategy>> GetExpiredStrategies();
    }

    public class DynamoDbInventoryService : IDynamoDbStrategyService
    {
        private int _dynamoDbBatchSize;
        private IDynamoDBContext _context;

        public AppLogger Logger { get; set; }

        public DynamoDbInventoryService(
            IDynamoDBContext context,
            int dynamoDbBatchSize,
            ILogger logger = null)
        {
            _dynamoDbBatchSize = dynamoDbBatchSize;
            _context = context;

            if (logger != null)
                Logger = new AppLogger(logger);
        }

        #region public methods
        public async Task<bool> Update(List<ProviderRefreshStrategy> inventoryList)
        {
            var existingAppointments = await GetDynamoInventory(inventoryList);
            var queuedAppointments = GetQueuedInventory(inventoryList);
            var deletedAppointments = existingAppointments?
                .Where(ea => !queuedAppointments
                    .Any(qa => qa.InventoryId == ea.InventoryId))?
                .ToList();
            var newAppointments = queuedAppointments?
                .Where(qa => !existingAppointments
                    .Any(ea => ea.InventoryId == qa.InventoryId))?
                .ToList();

            await InsertToDynamoDB(newAppointments);
            await DeleteFromDynamoDB(deletedAppointments);

            #region log slots count
            Write($"Timeslots existing: {existingAppointments?.Count()} " +
                $"Timeslots queued: {queuedAppointments?.Count()} " +
                $"Timeslots inserted: {newAppointments?.Count()} " +
                $"Timeslots deleted: {deletedAppointments?.Count()}");
            #endregion

            return true;
        }
        #endregion

        #region private methods
        private async Task<List<DynamoDbInventory>> Get(List<ProviderRefreshStrategy> inventories)
        {
            var dynamoDBInventoryList = new List<DynamoDbInventory>();
            foreach (var inventory in inventories)
            {
                var startDate = (string.IsNullOrEmpty(inventory.StartDate)
                    || DateTime.Parse(inventory.StartDate) == DateTime.UtcNow.Date)
                    ? DateTime.MinValue : DateTime.Parse(inventory.StartDate);
                var endDate = DateTime.Parse(inventory.EndDate);

                QueryFilter filter = new QueryFilter();
                filter.AddCondition("Pwid", QueryOperator.Equal, inventory.Pwid.ToUpper());
                filter.AddCondition(
                    "AppointmentDateTime",
                    QueryOperator.Between,
                    startDate.ToString("yyyy-MM-dd'T'HH:mm:ss.fffK", CultureInfo.InvariantCulture),
                    endDate.ToString("yyyy-MM-dd'T'HH:mm:ss.fffK", CultureInfo.InvariantCulture)
                );

                QueryOperationConfig queryConfig = new QueryOperationConfig
                {
                    Filter = filter,
                    Select = SelectValues.AllProjectedAttributes,
                    Limit = _dynamoDbBatchSize == 0 ? 25 : _dynamoDbBatchSize,
                    IndexName = "Pwid-AppointmentDateTime-index" //Todo: Move to appsettings
                };

                var inventoryData = await _context
                    .FromQueryAsync<DynamoDbInventory>(queryConfig)
                    .GetRemainingAsync();

                dynamoDBInventoryList.AddRange(inventoryData);

                LogTimeslotDetails(inventory, inventoryData);
            }

            return dynamoDBInventoryList;
        }

        private List<DynamoDbInventory> GetQueuedInventory(IEnumerable<Inventory> inventoryList)
        {
            return inventoryList
                .SelectMany(list => list
                    .TimeSlotList
                    .Where(x => string.IsNullOrWhiteSpace(list.StartDate) ||
                                x.Time >= DateTime.Parse(list.StartDate))
                    .Where(x => x.Time <= DateTime.Parse(list.EndDate))
                    .SelectMany(x => x.ToInventory(list.CreatedOn, list.AppointmentReasonlist)))
                .GroupBy(x => x.InventoryId)
                .Select(y => y.First())
                .ToList();
        }

        private async Task InsertToDynamoDB(List<DynamoDbInventory> newAppointments)
        {
            var batchSize = _dynamoDbBatchSize == 0 ? newAppointments.Count() : _dynamoDbBatchSize;
            if (newAppointments != null && newAppointments.Count() > 0)
            {
                var batches = newAppointments.SplitList(batchSize);
                foreach (var batch in batches)
                {
                    var batchWrite = _context.CreateBatchWrite<DynamoDbInventory>();
                    batchWrite.AddPutItems(batch);
                    await batchWrite.ExecuteAsync();
                }
            }
        }

        private async Task DeleteFromDynamoDB(List<DynamoDbInventory> deletedAppointments)
        {
            var batchSize = _dynamoDbBatchSize == 0 ? deletedAppointments.Count() : _dynamoDbBatchSize;
            if (deletedAppointments != null && deletedAppointments.Count() > 0)
            {
                var batches = deletedAppointments.SplitList(batchSize);
                foreach (var batch in batches)
                {
                    var batchWrite = _context.CreateBatchWrite<DynamoDbInventory>();
                    batchWrite.AddDeleteItems(batch);
                    await batchWrite.ExecuteAsync();
                }
            }
        }

        private void LogTimeslotDetails(Inventory inventory, List<DynamoDbInventory> inventoryData)
        {
            IDictionary<string, string> logProperties = new Dictionary<string, string>();
            logProperties.Add("sims.partner_id", inventory?.TimeSlotList?.FirstOrDefault()?.PartnerId);
            logProperties.Add("sims.pwid", inventory?.Pwid);
            logProperties.Add("sims.start_date", inventory?.StartDate);
            logProperties.Add("sims.end_date", inventory?.EndDate);
            logProperties.Add("sims.timeslot.in_db", inventoryData?.Count().ToString());
            logProperties.Add("sims.timeslot.count", inventory?.TimeSlotList?.Count().ToString());
            PushLogProperties(logProperties);
            Write($"TransactionId: {inventory?.TransactionId} " +
                       $"sims.partner_id: {inventory?.TimeSlotList?.FirstOrDefault()?.PartnerId} " +
                       $"sims.pwid: {inventory?.Pwid} " +
                       $"sims.start_date: {inventory?.StartDate} " +
                       $"sims.end_date: {inventory?.EndDate} " +
                       $"sims.timeslot.in_db: {inventoryData?.Count().ToString()} " +
                       $"sims.timeslot.count: {inventory?.TimeSlotList?.Count().ToString()}");
        }

        private void PushLogProperties(IDictionary<string, string> logProperties)
        {
            foreach (var prop in logProperties)
            {
                LogContext.PushProperty(prop.Key, prop.Value);
            }
        }

        protected virtual void Write(string msg)
        {
            Logger?.Write(msg);
        }
        #endregion
    }
}
