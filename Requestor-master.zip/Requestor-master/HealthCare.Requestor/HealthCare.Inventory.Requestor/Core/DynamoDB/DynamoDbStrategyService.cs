﻿using Amazon.DynamoDBv2.DataModel;
using Amazon.DynamoDBv2.DocumentModel;
using HealthCare.Inventory.RefreshQueue;
using HealthCare.InventoryLoader;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace HealthCare.Inventory.Requestor.Core.DynamoDB
{

    public interface IDynamoDbStrategyService
    {
        Task<bool> Update(List<ProviderRefreshStrategy> inventoryList);
        Task<List<ProviderRefreshStrategy>> GetExpiredStrategies(DateTime dateTime);
    }
    public class DynamoDbStrategyService : IDynamoDbStrategyService
    {
        private int _dynamoDbBatchSize;
        private IDynamoDBContext _context;

        public AppLogger Logger { get; set; }

        public DynamoDbStrategyService(
            IDynamoDBContext context,
            int dynamoDbBatchSize,
            ILogger logger = null)
        {
            _dynamoDbBatchSize = dynamoDbBatchSize;
            _context = context;

            if (logger != null)
                Logger = new AppLogger(logger);
        }
        public async Task<List<ProviderRefreshStrategy>> GetExpiredStrategies(DateTime dateTime)
        {
            var stopWatch = new System.Diagnostics.Stopwatch();
            stopWatch.Start();

            var currentDateTime = (DateTime.MinValue == dateTime) ? DateTime.UtcNow : dateTime;
            List<ProviderRefreshStrategy> providerStrategies = null;
            try
            {
                IEnumerable<ScanCondition> scanConditions = new List<ScanCondition>() { 
                     new ScanCondition("NextUpdate", ScanOperator.LessThan, currentDateTime.ToString("o"))
                };

                providerStrategies = await _context
                    .ScanAsync<ProviderRefreshStrategy>(scanConditions )
                    .GetRemainingAsync();
            }
            catch (Exception _Exceptoin)
            {

                Logger.Logger.LogError($"{_Exceptoin.Message}");
                throw (_Exceptoin);
            }

            stopWatch.Stop();
            Logger.Logger.LogInformation($"Execution took {stopWatch.ElapsedMilliseconds} ms: for DynamoDB (complete) to retrieve existing timeslots");
            return providerStrategies;
        }

        public async Task<bool> Update(List<ProviderRefreshStrategy> inventoryList)
        {
            try
            {
                inventoryList.ForEach(x => x.NextUpdate =
                    DateTime.UtcNow.AddMinutes(Convert.ToInt32(x.Interval))
                    .ToString("o"));
                var batchWrite = _context.CreateBatchWrite<ProviderRefreshStrategy>();
                batchWrite.AddPutItems(inventoryList);
                await batchWrite.ExecuteAsync();
                return true;
            }
            catch (Exception _Exceptoin)
            {

                Logger.Logger.LogError($"{_Exceptoin.Message}");
                throw (_Exceptoin);
            }
        }
    }
}
