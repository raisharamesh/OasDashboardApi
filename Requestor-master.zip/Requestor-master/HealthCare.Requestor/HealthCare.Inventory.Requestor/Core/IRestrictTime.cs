﻿using System.Collections.Generic;

namespace HealthCare.Inventory.Requestor
{
    public interface IRestrictTime
    {
        List<TimeRestriction> GetTimeRestrictions();
    }
}
