﻿using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;

namespace HealthCare.Inventory.Requestor
{
    public class AppSettings
    {
        public QueueConfiguration RefreshQueue { get; set; }
        public bool EnableDbLogger { get; set; }
        public int DynamoDbBatchSize { get; set; }
    }
    public class AwsCredentials
    {
        public string AccessKeyId { get; set; }
        public string SecretKey { get; set; }
        public string RegionName { get; set; }
        public bool UseAwsExecutionRole { get; set; }
    }


    public static class AppSettingsExtensions
    {
        public static AppSettings UseAwsExecutionRole(this AppSettings settings)
        {
            if(settings.RefreshQueue == null)
                return settings;

            settings.RefreshQueue.UseAwsExecutionRole = true;
            return settings;
        }

        public static List<string> GetMissingSettings(this Object settings)
        {
            var missingSettings = settings
                .GetType()
                .GetProperties()
                .Where(x => x.PropertyType == typeof(string))
                .Where(x => string.IsNullOrWhiteSpace((string)x.GetValue(settings)))
                .Select(x => x.Name)
                .ToList();

            var nestedObjectProps = settings
                .GetType()
                .GetProperties()
                .Where(x => x.PropertyType != typeof(string))
                .Where(x => x.PropertyType.IsClass);

            var nestedNullObjs = nestedObjectProps
                .Where(x => x.GetValue(settings) == null)
                .Select(x => x.Name)
                .ToList();

            var nestedMissingSettings = nestedObjectProps
                .Where(x => x.GetValue(settings) != null)
                .SelectMany(x => {
                    return
                        GetMissingSettings(x.GetValue(settings))
                            .Select(s => $"{x.Name}.{s}");
                })
                .ToList();

            missingSettings.AddRange(nestedNullObjs);
            missingSettings.AddRange(nestedMissingSettings);

            return missingSettings;
        }

        public static AppSettings Verify(this AppSettings settings)
        {
            var missingSettings = settings.GetMissingSettings();
            
            // It is okay for these fields to be empty.
            if(settings.RefreshQueue?.UseAwsExecutionRole == true)
                missingSettings = missingSettings
                    .Where(x => x != "RefreshQueue.AccessKeyId")
                    .Where(x => x != "RefreshQueue.SecretKey")
                    .Where(x => x != "RefreshQueue.RegionName")
                    .ToList();

            if (missingSettings == null || missingSettings.Any())
                throw new ApplicationException("The following settings are missing: " + string.Join(", ", missingSettings));

            return settings;
        }
    }
}
