﻿using HealthCare.Inventory.RefreshQueue;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace HealthCare.Inventory.Requestor
{
    public interface IDatabase
    {
        Task<List<ProviderRefreshStrategy>> GetExpiredStrategies(DateTime dateTime);
        Task<IList<string>> GetActivePartners();
        Task<bool> ChangeLastUpdate(IList<ProviderStrategyWithPartnerInfo> strategiestoUpdate);
        Task<List<string>> GetNewProviders(IEnumerable<PartnerProvider> allProviders);
        Task<bool> SyncProviders(List<ProviderRefreshStrategy> providers);
        Task<bool> AddDefaultStrategies(List<string> pwids);
    }
}
