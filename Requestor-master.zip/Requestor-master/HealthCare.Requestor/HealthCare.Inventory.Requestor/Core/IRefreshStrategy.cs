﻿using HealthCare.Inventory.RefreshQueue;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace HealthCare.Inventory.Requestor
{
    public interface IRefreshStrategy
    {
        string Name { get; }
        int NumOfMins { get; }
        IList<ProviderStrategyWithPartnerInfo> GetProvidersToUpdate(IList<ProviderStrategyWithPartnerInfo> providerStrategies);
    }
}
