﻿using System;
using System.Collections.Generic;
using System.Text;

namespace HealthCare.Inventory.Requestor
{
   public class RequestLimit
    {
        public string SponsorCode { get; set; }
        public int CeilingLimit { get; set; }
    }
}
