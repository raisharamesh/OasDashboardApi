﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace HealthCare.Inventory.Requestor
{
    public static class RestrictCallTimeExtension
    {
        public static IList<ProviderStrategyWithPartnerInfo> RestrictCallTime(
            this IList<ProviderStrategyWithPartnerInfo> inventory,
            IList<IRefreshStrategy> refreshStrategies)
        {
            return inventory.RestrictCallTime(refreshStrategies, DateTime.UtcNow);
        }

        public static IList<ProviderStrategyWithPartnerInfo> RestrictCallTime(
            this IList<ProviderStrategyWithPartnerInfo> inventory,
            IList<IRefreshStrategy> refreshStrategies, 
            DateTime utcNow)
        {
            if (refreshStrategies.IsEmpty())
                return inventory;

            var invalidStrategies = new List<IRefreshStrategy>();
            foreach (var restrictStrategy in refreshStrategies.Where(x => x is IRestrictTime))
            {
                var timeRestrictions = ((IRestrictTime)restrictStrategy).GetTimeRestrictions();

                if (!timeRestrictions.Any(x => x.WithinRestrictedHours(utcNow)))
                    invalidStrategies.Add(restrictStrategy);
            }

            return inventory
                .ToList();
        }
    }
}
