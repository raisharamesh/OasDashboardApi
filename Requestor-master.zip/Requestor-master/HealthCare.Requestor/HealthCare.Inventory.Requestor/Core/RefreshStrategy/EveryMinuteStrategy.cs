﻿using System.Collections.Generic;

namespace HealthCare.Inventory.Requestor.RefreshStrategy
{
    /// <summary>
    /// DoNotUpdateStrategy class
    /// </summary>
    public class EveryMinuteStrategy : EveryIntervalStrategy
    {
        public EveryMinuteStrategy()
            : base("EveryMinute", 1) { }
    }
}
