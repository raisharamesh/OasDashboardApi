﻿using System.Collections.Generic;

namespace HealthCare.Inventory.Requestor.RefreshStrategy
{
    /// <summary>
    /// DoNotUpdateStrategy class
    /// </summary>
    public class DoNotUpdateStrategy : IRefreshStrategy
    {
        public string Name => "DoNotUpdate";

        public int NumOfMins => 0;

        public DoNotUpdateStrategy()
        {
        }

        public IList<ProviderStrategyWithPartnerInfo> GetProvidersToUpdate(
            IList<ProviderStrategyWithPartnerInfo> providerStrategies)
        {
            return new List<ProviderStrategyWithPartnerInfo>();
        }
    }
}
