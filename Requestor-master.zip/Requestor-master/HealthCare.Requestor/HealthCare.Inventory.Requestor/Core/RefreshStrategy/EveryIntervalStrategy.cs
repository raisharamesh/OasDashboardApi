﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;

namespace HealthCare.Inventory.Requestor.RefreshStrategy
{
    public class EveryIntervalStrategy : IRefreshStrategy
    {
        public int NumOfMins { get; set; }

        public string Name { get; set; }

        public EveryIntervalStrategy(string name, int numOfMins)
        {
            Name = name;
            NumOfMins = numOfMins;
        }

        public IList<ProviderStrategyWithPartnerInfo> GetProvidersToUpdate(
            IList<ProviderStrategyWithPartnerInfo> providerStrategies)
        {

            var pwidsToUpdate = providerStrategies
                .Where(x => Ago(Convert.ToDateTime(x.NextUpdate)).TotalMinutes <= Ago(DateTime.UtcNow).TotalMinutes)
                .OrderBy(x => x.NextUpdate)
                .ToList();


            return pwidsToUpdate;
        }

        public virtual DateTime GetUtcNow()
        {
            return DateTime.UtcNow;
        }

        public TimeSpan Ago(DateTime pastTime)
        {
            return GetUtcNow().Subtract(pastTime);
        }
    }
}