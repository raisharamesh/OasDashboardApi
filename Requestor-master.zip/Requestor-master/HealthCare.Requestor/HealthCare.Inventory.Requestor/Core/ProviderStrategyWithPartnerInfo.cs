﻿using HealthCare.Inventory.RefreshQueue;
using System;

namespace HealthCare.Inventory.Requestor
{
    public class ProviderStrategyWithPartnerInfo : ProviderRefreshStrategy
    {
        public string SponsorCode { get; set; }
    }

    public static class InventoryRefreshRequestExtensions
    {
        //public static RefreshQueue.ProviderRefreshStrategy ToRequest(
        //    this ProviderStrategyWithPartnerInfo provider)
        //{
        //    var refreshRequest = new RefreshQueue.ProviderRefreshStrategy
        //    { 
        //        ProviderId = provider.ProviderId.Trim(),
        //        LastUpdated = provider.EndOffset.GetEndDate().ToString(),
        //        TransactionId = Guid.NewGuid().ToString()
        //    };

        //    // if no start date is provided, 
        //    // then the inventory will be updated to the end date
        //    if (provider.StartOffset > 0)
        //        refreshRequest.StartDate = provider.StartOffset.GetStartDate().ToString();

        //    return refreshRequest;
        //}
    }
}
