﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Logging.Console;

namespace HealthCare.Inventory.Requestor.Sql
{
    public partial class SimsDbContext : DbContext
    {
        private string connectionString;
        private bool enableDbLogging;
        public virtual DbSet<RefreshStrategy> RefreshStrategy { get; set; }
        public virtual DbSet<Provider> Provider { get; set; }

        public virtual DbSet<ActivePartners> ActivePartners { get; set; }

        public static readonly LoggerFactory MyConsoleLoggerFactory = new LoggerFactory(
            new[] {
#pragma warning disable CS0618 // Type or member is obsolete
                new ConsoleLoggerProvider((category, level) =>
                    category == DbLoggerCategory.Database.Command.Name &&
                    level == LogLevel.Information, true)
#pragma warning restore CS0618 // Type or member is obsolete
            });

        public SimsDbContext(string connectionString, bool enableDbLogging)
        {
            this.connectionString = connectionString;
            this.enableDbLogging = enableDbLogging;
        }

        public SimsDbContext(DbContextOptions options)
            : base(options) { }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
                optionsBuilder
                    .UseSqlServer(connectionString);

                if (enableDbLogging)
                    optionsBuilder
                        .UseLoggerFactory(MyConsoleLoggerFactory)
                        .EnableSensitiveDataLogging(true);
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<RefreshStrategy>(entity =>
            {
                entity.HasIndex(e => new { e.Id, e.Pwid, e.Strategy, e.StartOffset, e.EndOffset, e.LastUpdated })
                    .HasName("IX_RefreshStrategy_pwid_include_1");

                entity.Property(e => e.LastUpdated).HasColumnType("datetime");

                entity.Property(e => e.Strategy)
                    .IsRequired()
                    .HasMaxLength(255)
                    .IsUnicode(false);

                //entity.Property(e => e.CreatedBy)
                //    .IsRequired()
                //    .HasMaxLength(50)
                //    .IsUnicode(false);

                entity.Property(e => e.Pwid)
                    .IsRequired()
                    .HasMaxLength(10)
                    .IsUnicode(false);
            });
        }
    }
}
