﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace HealthCare.Inventory.Requestor.Sql
{
    [Table("Inventory")]
    public partial class Inventory
    {
        public int InventoryId { get; set; }
        public string TimeslotId { get; set; }
        public string Pwid { get; set; }
        public string OfficeCode { get; set; }
        public string PartnerCode { get; set; }
        public string PartnerPracticeId { get; set; }
        public string PartnerProviderId { get; set; }
        public string PartnerOfficeId { get; set; }
        public string AppointmentType { get; set; }
        public DateTime AppointmentDateTime { get; set; }
        public DateTime? AppointmentDateTimeUtc { get; set; }
        public bool IsAvailable { get; set; }
        public DateTime LoadDate { get; set; }
        public DateTime UpdatedDate { get; set; }
    }
}
