﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace HealthCare.Inventory.Requestor.Sql
{
    [Table("ActivePartners")]
    public partial class ActivePartners
    {
        [Key]
        public string PartnerCode { get; set; }
        public string MetaData { get; set; }
        public int IsLive { get; set; }
    }
}