﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;


namespace HealthCare.Inventory.Requestor.Sql
{
    public class SqlDatabase : IDatabase
    {
        string connectionString;
        bool enableDbLogging;

        public SqlDatabase(string connectionString)
            : this(connectionString, false) { }

        public SqlDatabase(string connectionString, bool enableDbLogging)
        {
            this.connectionString = connectionString;
            this.enableDbLogging = enableDbLogging;
        }

        public async Task<IList<ProviderRefreshStrategy>> GetProviderStrategy(string strategy = null)
        {
            using (var dbContext = CreateDbContext())
            {
                var query = dbContext
                .RefreshStrategy
                .AsNoTracking();

                if (!string.IsNullOrEmpty(strategy))
                    query = query.Where(x => x.Strategy.Trim().ToUpper() == strategy.ToUpper());

                return await query
                    .Select(x => Map(x))
                    .ToListAsync();
            }
        }

        public async virtual Task<bool> ChangeLastUpdate(IList<ProviderStrategyWithPartnerInfo> strategiestoUpdate)
        {
            if (strategiestoUpdate.IsEmpty())
                return true;

            using (var dbContext = CreateDbContext())
            {

                foreach (var providerRefreshStrategy in strategiestoUpdate)
                {
                    var now = DateTime.UtcNow;
                    var providersToBeUpdated = await dbContext
                        .RefreshStrategy
                        .Where(x =>  x.Id == providerRefreshStrategy.Id)
                        .ToListAsync();

                    providersToBeUpdated.ForEach(x =>
                    {
                        x.LastUpdated = now;
                    });
                }
                await dbContext.SaveChangesAsync();
            }

            return true;
        }

        public async virtual Task<bool> SyncProviders(IEnumerable<PartnerProvider> providers)
        {
            if (providers == null || !providers.Any())
                return true;

            var allOasPwids = providers.Select(p => p.Pwid.ToLower()).ToList();

            using (var dbContext = CreateDbContext())
            {
                var alreadyExists = dbContext.Provider
                    .Where(p => allOasPwids.Contains(p.Pwid.Trim().ToLower()))
                    .ToList();

                //set isActive to true if not.
                alreadyExists
                    .Where(x => !x.IsActive)
                    .ToList()
                    .ForEach(p => p.IsActive = true);

                var pwidsToAdd = allOasPwids.Except(
                    alreadyExists.Select(p => p.Pwid.Trim().ToLower()))
                    .ToList();

                dbContext.AddRange(
                    providers.Where(pr => pwidsToAdd.Contains(pr.Pwid.ToLower()))
                    .Select(p => Map(p)));

                await dbContext.SaveChangesAsync();

                return true;
            }
        }

        public async virtual Task<List<string>> GetNewProviders(IEnumerable<PartnerProvider> allProviders)
        {
            if (allProviders == null || !allProviders.Any())
                return null;

            var allOasPwids = allProviders.Select(p => p.Pwid.ToLower()).ToList();
            var newProviders = new List<string>();

            using (var dbContext = CreateDbContext())
            {
                var existingProviders = await dbContext.Provider
                    .Select(p => p.Pwid.Trim().ToLower())
                    .ToListAsync();

                newProviders = allOasPwids.Except(existingProviders).ToList();
            }

            return newProviders;
        }

        public async virtual Task<bool> AddDefaultStrategies(List<string> pwids)
        {
            var allStrategies = new List<RefreshStrategy>();

            foreach (var pwid in pwids)
            {
                var strategies = new[] {
                    new RefreshStrategy
                    {
                        Pwid = pwid,
                        Strategy = "Every1Hour",
                        StartOffset = 1,
                        EndOffset = 14,
                        LastUpdated = DateTime.UtcNow
                    },
                    new RefreshStrategy
                    {
                        Pwid = pwid,
                        Strategy = "Every2Hour",
                        StartOffset = 15,
                        EndOffset = 29,
                        LastUpdated = DateTime.UtcNow
                    },
                    new RefreshStrategy
                    {
                        Pwid = pwid,
                        Strategy = "Every12Hour",
                        StartOffset = 30,
                        EndOffset = 89,
                        LastUpdated = DateTime.UtcNow
                    },
                    new RefreshStrategy
                    {
                        Pwid = pwid,
                        Strategy = "Every24Hour",
                        StartOffset = 90,
                        EndOffset = 179,
                        LastUpdated = DateTime.UtcNow
                    },
                }.ToList();

                allStrategies.AddRange(strategies);
            }

            using (var dbContext = CreateDbContext())
            {
                dbContext.RefreshStrategy.AddRange(allStrategies);
                await dbContext.SaveChangesAsync();
            }

            return true;
        }

        public async Task<IList<string>> GetActivePartners()
        {
            using (var dbContext = CreateDbContext())
            {
                var query = dbContext
                .ActivePartners
                .Where(x => x.IsLive.Equals(1))
                .AsNoTracking();

                return await query
                    .Select(x => x.PartnerCode.Trim()).ToListAsync();
            }
        }

        public virtual SimsDbContext CreateDbContext()
        {
            return new SimsDbContext(connectionString, enableDbLogging);
        }

        private static ProviderRefreshStrategy Map(RefreshStrategy item)
        {
            return new ProviderRefreshStrategy
            {
                Id = item.Id,
                Pwid = item.Pwid.Trim(),
                StrategyName = item.Strategy,
                StartOffset = item.StartOffset.Value,
                EndOffset = item.EndOffset.Value,
                LastUpdated = item.LastUpdated
            };
        }

        private static Provider Map(PartnerProvider p)
        {
            return new Provider()
            {
                Pwid = p.Pwid.Trim(),
                PartnerCode = p.PartnerCode.Trim(),
                IsActive = true,
                ProviderInventoryScheduleId = null,
                CreatedBy = "SIMS",
                CreatedOn = DateTime.UtcNow,
                LastRunHangfire = null,
                IsPullNeeded = false
            };
        }


    }
}
