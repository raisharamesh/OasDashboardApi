﻿using System;
using System.ComponentModel.DataAnnotations.Schema;

namespace HealthCare.Inventory.Requestor.Sql
{
    [Table("Provider")]
	public partial class Provider
    {
        public int ProviderId { get; set; }
        public string Pwid { get; set; }
        public string PartnerCode { get; set; }
        public bool IsActive { get; set; }
        public int? ProviderInventoryScheduleId { get; set; }
        public string CreatedBy { get; set; }
        public DateTime CreatedOn { get; set; }
        public DateTime? LastRunHangfire { get; set; }
        public bool? IsPullNeeded { get; set; }
    }
}
