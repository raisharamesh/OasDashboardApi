﻿using System;
using System.ComponentModel.DataAnnotations.Schema;

namespace HealthCare.Inventory.Requestor.Sql
{
    [Table("RefreshStrategy")]
	public partial class RefreshStrategy
    {
        public int Id { get; set; }
        public string Pwid { get; set; }
        public string Strategy { get; set; }
        public int? StartOffset { get; set; }
        public int? EndOffset { get; set; }
        public DateTime LastUpdated { get; set; }
    }
}
