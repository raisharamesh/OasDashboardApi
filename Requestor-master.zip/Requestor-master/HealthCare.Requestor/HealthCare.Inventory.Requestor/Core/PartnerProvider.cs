﻿using System;
using System.Collections.Generic;
using System.Text;

namespace HealthCare.Inventory.Requestor
{
    public class PartnerProvider
    {
        public string Pwid { get; set; }
        public string PartnerCode { get; set; }

        public string SponsorCode { get; set; }
    }
}
