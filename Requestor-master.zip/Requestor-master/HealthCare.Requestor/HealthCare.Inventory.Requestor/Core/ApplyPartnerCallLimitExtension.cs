﻿using System.Collections.Generic;
using System.Linq;

namespace HealthCare.Inventory.Requestor
{
    public static class ApplyPartnerCallLimitExtension
    {
        const int CallLimit = 100;

        public static IList<ProviderStrategyWithPartnerInfo> ApplyPartnerCallLimit(
            this IList<ProviderStrategyWithPartnerInfo> inventory)
        {
            var limit = inventory
                .GroupBy(x => x.PartnerCode)
                .SelectMany((v,i) => v.Take(CallLimit))
                .ToList();

            //limit
            //    .GroupBy(x => x.PartnerCode)
            //    .ToList()
            //    .ForEach(x => System.Console.WriteLine($"Applying ceiling limit - Taking {x.Count()} for {x.Key}"));

            return limit;
        }
    }
}
