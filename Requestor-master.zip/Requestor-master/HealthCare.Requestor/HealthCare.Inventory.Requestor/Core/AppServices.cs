﻿using Microsoft.Extensions.Logging;
using HealthCare.Inventory.RefreshQueue;
using System.Collections.Generic;
using HealthCare.Inventory.Requestor.DynamoDB;

namespace HealthCare.Inventory.Requestor
{
    public class AppServices
    {
        public ILogger Logger { get; set; }
        public IRefreshQueue IncomingQueue { get; set; }
        public IList<IRefreshStrategy> RefreshStrategies { get; set; }
        public IDatabase DynmoDbDatabase { get; set; }
    }
}
