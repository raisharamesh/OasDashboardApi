﻿namespace HealthCare.Inventory.Requestor
{
    public class QueueConfiguration
    {
        public string Url { get; set; }
        public string AccessKeyId { get; set; }
        public string SecretKey { get; set; }
        public string RegionName { get; set; }
        public bool UseAwsExecutionRole { get; set; }
    }
}
