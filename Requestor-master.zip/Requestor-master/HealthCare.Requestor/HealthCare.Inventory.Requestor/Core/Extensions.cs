﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace HealthCare.Inventory.Requestor
{
    public static class Extensions
    {
        public static DateTime GetStartDate(this int startOffSet, DateTime asOfDateUtc)
        {
            return asOfDateUtc.Date.AddDays(startOffSet);
        }
        public static long ToEpoch(this DateTime dateTime) => (long)(dateTime - new DateTime(1970, 1, 1)).TotalSeconds;
        public static DateTime FromEpoch(this long epoch) => new DateTime(1970, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified).AddSeconds(epoch);

        public static DateTime GetStartDate(this int startoffset)
        {
            return GetStartDate(startoffset, DateTime.UtcNow);
        }
        public static DateTime GetEndDate(this int endOffset, DateTime asOfDateUtc)
        {
            return asOfDateUtc
                .Date
                .AddDays(endOffset + 1)
                .AddMilliseconds(-1.0);
        }

        public static DateTime GetEndDate(this int endOffset)
        {
            return GetEndDate(endOffset, DateTime.UtcNow);
        }

        public static bool IsEmpty<T>(this IEnumerable<T> list)
        {
            return list == null || !list.Any();
        }
    }
}
