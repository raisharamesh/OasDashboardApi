using System;
using System.Collections.Generic;

namespace HealthCare.Inventory.RefreshQueue
{
    public class InventoryRefreshResponse
    {
        public string Pwid { get; set; }
        public string Status { get; set; }
    }
}
