using Amazon.DynamoDBv2.DataModel;

namespace HealthCare.Inventory.RefreshQueue
{
    [DynamoDBTable("ProviderStrategy")]
    public class ProviderRefreshStrategy
    {
        [DynamoDBHashKey]
        public string Id { get; set; }
        [DynamoDBProperty]
        public string ProviderId { get; set; }
        [DynamoDBProperty]
        public string StartOffset { get; set; }
        [DynamoDBProperty]
        public string Interval { get; set; }
        [DynamoDBProperty]
        public string EndOffset { get; set; }
        [DynamoDBProperty]
        public string NextUpdate { get; set; }

        [DynamoDBProperty]
        public string PartnerCode { get; set; }
    }
}
