using Amazon.SQS;
using Amazon.SQS.Model;
using Microsoft.Extensions.Logging;
using System.Collections.Generic;
using System.Linq;

namespace HealthCare.Inventory.RefreshQueue
{
    public class SqsRefreshQueue : IRefreshQueue
    {
        private IAmazonSQS client;
        private ILogger logger;
        private string queueUrl;
        private List<InventoryRefreshResponse> refreshResponse;

        public SqsRefreshQueue(string queueUrl,ILogger logger, AmazonSQSClient sqsClient)
        {
            this.client = sqsClient;
            this.queueUrl = queueUrl;
            this.logger = logger;
            this.refreshResponse = new List<InventoryRefreshResponse>();
        }


        public SqsRefreshQueue(IAmazonSQS client, string queueUrl)
        {
            this.client = client;
            this.queueUrl = queueUrl;
        }

        public Message Get()
        {
            var request = new ReceiveMessageRequest {
                WaitTimeSeconds = 20,
                MaxNumberOfMessages = 1,
                QueueUrl = queueUrl
            };

            return client
                .ReceiveMessageAsync(request)
                .GetAwaiter()
                .GetResult()
                .Messages
                .FirstOrDefault();
        }

        public void Delete(Message msg)
        {
            var deleteRequest = new DeleteMessageRequest {
                ReceiptHandle = msg.ReceiptHandle,
                QueueUrl = queueUrl
            };

            client
                .DeleteMessageAsync(deleteRequest)
                .GetAwaiter()
                .GetResult();
        }

        private void Send(RefreshRequestMessage inventory)
        {
            var msg = inventory.ToJson();

            var request = new SendMessageRequest
            {
                QueueUrl = queueUrl,
                MessageBody = msg
            };

            client
                .SendMessageAsync(request)
                .GetAwaiter()
                .GetResult();
			
        }

        public void Send(IList<RefreshRequestMessage> inventory)
        {
            if (inventory == null)
                return;

			foreach (var item in inventory)
				Send(item);
        }
        
        private void Write(string msg)
        {
            if (logger != null)
                logger.LogInformation(msg);
        }
    }
}