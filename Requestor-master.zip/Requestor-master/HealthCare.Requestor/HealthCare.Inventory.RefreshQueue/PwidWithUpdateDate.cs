﻿namespace HealthCare.Inventory.RefreshQueue
{
    public class PwidWithUpdateDate
    {
    }
}