using Amazon.SQS.Model;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace HealthCare.Inventory.RefreshQueue
{
    public interface IRefreshQueue
    {
        Message Get();
        void Delete(Message msg);
        void Send(IList<RefreshRequestMessage> inventory);
    }
}