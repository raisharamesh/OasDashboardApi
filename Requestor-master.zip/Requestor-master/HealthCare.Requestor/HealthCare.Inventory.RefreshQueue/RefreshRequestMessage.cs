﻿using HealthCare.Inventory.RefreshQueue;
using System;
using System.Collections.Generic;

namespace HealthCare.Inventory.RefreshQueue
{
    public class RefreshRequestMessage
    {
        public string Id { get; set; }
        public string Pwid { get; set; }
        public string PartnerCode { get; set; }
        public string StartDate { get; set; }
        public string EndDate { get; set; }
        public string TransactionId { get { return Guid.NewGuid().ToString(); } }

    }
}
