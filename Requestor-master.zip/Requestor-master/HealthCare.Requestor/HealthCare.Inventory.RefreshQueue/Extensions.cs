﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace HealthCare.Inventory.RefreshQueue
{
    public static class Extensions
    {
        public static string ToJson(this ProviderRefreshStrategy inventory)
        {
            if (inventory == null)
                return null;

            return JsonConvert.SerializeObject(inventory);
        }

        public static string ToJson(this RefreshRequestMessage inventory)
        {
            if (inventory == null)
                return null;

            return JsonConvert.SerializeObject(inventory);
        }
    }
}
