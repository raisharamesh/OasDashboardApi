using Amazon.Lambda.Core;
using System;
using Microsoft.Extensions.Logging;
using System.Threading.Tasks;

[assembly: LambdaSerializer(typeof(Amazon.Lambda.Serialization.Json.JsonSerializer))]

namespace HealthCare.Inventory.Requestor.Lambda
{
    public class Function
    {
        readonly string instanceId;
        readonly AppSettings settings;
        readonly AppServices services;
        readonly RequestorApplication app;

        public Function()
        {
            instanceId = DateTime.Now.ToString().GetHashCode().ToString("x");

            settings = Bootstrapper
                    .GetSettings()
                    .UseAwsExecutionRole()
                    .Verify();

            services = settings.GetServices();

            app = new RequestorApplication(services);
        }

        public async Task<bool> FunctionHandler(ILambdaContext context)
        {
            try
            {
                await app.DespatchRefreshRequests();
                return true;
            }
            catch (Exception e)
            {
                Write(e, "HealthCare.Inventory.Requestor.LambdaException - FunctionHandler");
                throw;
            }
        }

        public void Write(Exception ex, string msg) => services.Logger.LogError(ex, msg);
    }
}
