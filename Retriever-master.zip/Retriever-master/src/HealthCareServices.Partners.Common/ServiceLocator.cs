﻿using System;

namespace HealthCareServices.Partners.Common
{
    public interface IServiceLocator
    {
        IPartnerService LocatePartner(string partnerCode);
    }
    public class ServiceLocator : IServiceLocator
    {
        private readonly Func<string, IPartnerService> _serviceAccessor;

        public ServiceLocator(Func<string, IPartnerService> serviceAccessor)
        {
            _serviceAccessor = serviceAccessor;
        }

        public IPartnerService LocatePartner(string partnerCode)
        {
            var service = _serviceAccessor(partnerCode.ToUpper());

            if (service == null)
            {
                throw new Exception("Unable to locate partner code");
            }
            return service;
        }
    }
}
