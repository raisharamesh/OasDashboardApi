﻿using System;
using System.Collections.Generic;
using System.Text;

namespace HealthCareServices.Partners.Common
{
    public class Inventory
    {
        public string Pwid { get; set; }
        public string StartDate { get; set; }
        public string EndDate { get; set; }
        public string TransactionId { get; set; }
        public IList<TimeSlot> TimeSlotList { get; set; }
        public IList<AppointmentReason> AppointmentReasonlist { get; set; }
        public DateTime CreatedOn { get; set; }
    }
}
