﻿using Microsoft.AspNetCore.Http.Extensions;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace HealthCareServices.Partners.Common
{
    public interface IJustPost
    {
        HttpClient Client { get; }
        Task<TOut> Post<T, TOut>(string requestUrl, T postBody, JsonSerializerSettings jsonSerializerSettings);
        Task<TOut> Post<T, TOut>(string requestUrl, T postBody);
        Task<T> Get<T>(string requestUrl);
        Task<T> Get<T>(string requestUrl, IEnumerable<KeyValuePair<string, string>> urlParameters);
        Task<T> Delete<T>(string requestUrl);
    }

    public class JustPost : IJustPost
    {
        public HttpClient Client { get; private set; }

        public JustPost(HttpClient client)
        {
            Client = client;
        }

        public virtual async Task<TOut> Post<T, TOut>(string relativeAddress, T postBody)
        {
            var content = new StringContent(
                JsonConvert.SerializeObject(postBody), Encoding.UTF8, "application/json");

            TOut output;
            using (var response = await Client.PostAsync(relativeAddress, content))
            {
                response.EnsureSuccessStatusCode();
                output = await response.Content.ReadAsAsync<TOut>();
            }

            return output;
        }
        public virtual async Task<TOut> Post<T, TOut>(string relativeAddress, T postBody, JsonSerializerSettings jsonSerializerSettings)
        {
            var content = new StringContent(
                JsonConvert.SerializeObject(postBody, jsonSerializerSettings), Encoding.UTF8, "application/json");

            TOut output;
            using (var response = await Client.PostAsync(relativeAddress, content))
            {
                response.EnsureSuccessStatusCode();
                output = await response.Content.ReadAsAsync<TOut>();
            }

            return output;
        }
        public virtual async Task<T> Get<T>(string relativeAddress)
        {
            T output;
            using (var response = await Client.GetAsync(relativeAddress))
            {
                output = await response.Content.ReadAsAsync<T>();
            }

            return output;
        }
        public virtual async Task<T> Get<T>(
            string relativeAddress, IEnumerable<KeyValuePair<string, string>> urlParameters)
        {
            if (relativeAddress.EndsWith("/"))
                relativeAddress = relativeAddress.TrimEnd('/');

            var queryString = new QueryBuilder(urlParameters).ToQueryString();

            T output;
            using (var response = await Client.GetAsync($"{relativeAddress}{queryString}"))
            {
                output = await response.Content.ReadAsAsync<T>();
            }

            return output;
        }

        public virtual async Task<T> Delete<T>(string relativeAddress)
        {
            T output;
            using (var response = await Client.DeleteAsync(relativeAddress))
                output = await response.Content.ReadAsAsync<T>();

            return output;
        }
    }

    public class PostArgs<T>
    {
        public Dictionary<string, string> Headers { get; set; }
        public Uri Uri { get; set; }
        public T ObjToPost { get; set; }
        public string AcceptType { get; set; }
        public string UserAgent { get; set; }
        public TimeSpan[] TimeoutAttempts { get; set; }
    }
}
