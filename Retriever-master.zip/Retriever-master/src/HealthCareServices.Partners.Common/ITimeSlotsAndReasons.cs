﻿using System;
using System.Collections.Generic;

namespace HealthCareServices.Partners.Common
{
    public interface ITimeSlotsAndReasons
    {
        List<TimeSlot> TimeSlotList { get; set; }
        List<AppointmentReason> AppointmentReasonList { get; set; }
        List<AppointmentMessage> AppointmentMessages { get; set; }
        int NewPatientTimeSlotCount { get; set; }
        int ExistingPatientTimeSlotCount { get; set; }
        int OtherPatientTimeSlotCount { get; set; }
        bool HasReminderReason { get; set; }
    }

    public class TimeSlot
    {
        public bool HasAppointmentReasons { get; }
        public string AppointmentCategory { get; set; }
        public string Type { get; set; }
        public int Length { get; set; }
        public DateTime UtcTime { get; set; }
        public DateTime Time { get; set; }
        public string PartnerReasonIdList { get; set; }
        public List<string> PartnerReasonIds { get; set; }
        public string PartnerDepartmentId { get; set; }
        public string PartnerSiteId { get; set; }
        public string PartnerProviderId { get; set; }
        public string PartnerId { get; set; }
        public string OfficeId { get; set; }
        public string Pwid { get; set; }
        public string PartnerPracticeId { get; set; }
        public string Id { get; set; }
        public string InventoryId { get; set; }
        public string ProviderId { get; set; }
        public string Url { get; set; }
    }

    public class AppointmentReason
    {
        public string ReasonId { get; set; }
        public string Reason { get; set; }
        public string Reasontype { get; set; }
        public string Description { get; set; }
        public int AppointmentCategoryId { get; set; }
        public string AppointmentCategoryName { get; set; }
        public int AppointmentDuration { get; set; }
        public bool IsDefaultReason { get; set; }
        public string ReasonCode { get; set; }
    }

    public class AppointmentMessage
    {
        public string AppointmentCategory { get; set; }
        public bool IsAllowed { get; set; }
        public string Message { get; set; }
    }

    public interface ITimeSlotsRequest
    {
        string PartnerPracticeId { get; set; }
        string PartnerOfficeId { get; set; }
        string PartnerProviderId { get; set; }
        string PartnerReasonIdList { get; set; }
        string ProviderId { get; set; }
        string PartnerId { get; set; }
        DateTime? StartDate { get; set; }
        DateTime? EndDate { get; set; }
        int? NumberOfDays { get; set; }
        string OfficeCode { get; set; }
        string AppointmentTypeId { get; set; }
    }

    public class TimeSlotsRequest: ITimeSlotsRequest
    {
        public string PartnerPracticeId { get; set; }
        public string PartnerOfficeId { get; set; }
        public string PartnerProviderId { get; set; }
        public string PartnerReasonIdList { get; set; }
        public string ProviderId { get; set; }
        public string PartnerId { get; set; }
        public DateTime? StartDate { get; set; }
        public DateTime? EndDate { get; set; }
        public int? NumberOfDays { get; set; }
        public string OfficeCode { get; set; }
        public string AppointmentTypeId { get; set; }
    }

    public class TimeSlotsAndReasons : ITimeSlotsAndReasons
    {
        public TimeSlotsAndReasons()
        { }

        public List<TimeSlot> TimeSlotList { get; set; }
        public List<AppointmentReason> AppointmentReasonList { get; set; }
        public List<AppointmentMessage> AppointmentMessages { get; set; }
        public int NewPatientTimeSlotCount { get; set; }
        public int ExistingPatientTimeSlotCount { get; set; }
        public int OtherPatientTimeSlotCount { get; set; }
        public bool HasReminderReason { get; set; }
    }
}
