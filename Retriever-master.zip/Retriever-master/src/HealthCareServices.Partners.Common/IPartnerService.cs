﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace HealthCareServices.Partners.Common
{
    public interface IPartnerService
    {
        Task<Inventory> GetTimeSlots(ITimeSlotsRequest timeSlotsRequest);

        Task<string> BookAppointment();

        Task<bool> CancelAppointment(string appointmentId);
    }
}
