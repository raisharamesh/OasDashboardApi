﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace HealthCare.Fortis.DataProviders
{
    public class TimeslotDataService : IDisposable
    {
        public TimeslotDataService()
        {

        }

        public async Task<List<Timeslot>> GetProviderInventory(string pwid, DateTime? startDateTime, DateTime? endDateTime)
        {

            string filepath = $"{Utils.UtilityService.AssemblyDirectory}\\Data\\ProviderInventory.json";
            var inventoryList =
                await Utils.UtilityService.ReadFromJsonFile<List<Timeslot>>(filepath);
            inventoryList = inventoryList.Select(c => { c.Pwid = pwid; return c; }).ToList();
            inventoryList = inventoryList.Select(c => { c.InventoryId = c.InventoryId.Replace("FORTISJOHN", pwid); return c; }).ToList();
            var windowDateTime = startDateTime.HasValue ? startDateTime : DateTime.Now;
            var windowDays = Utils.UtilityService.CalculateWindowDays(windowDateTime.Value, endDateTime.GetValueOrDefault());
            endDateTime = endDateTime ?? windowDateTime.Value.AddDays(windowDays);

            #region log slots count
            //Write($"TransactionId: {inventory?.TransactionId} in Redis, " +
            //          $"sims.partner_id: {inventory?.TimeSlotList?.FirstOrDefault()?.PartnerId}, " +
            //          $"sims.pwid: {inventory?.Pwid}, " +
            //          $"sims.start_date: {inventory?.StartDate}, " +
            //          $"sims.end_date: {inventory?.EndDate}, " +
            //          $"sims.timeslot.in_db: {appointmentCount.Existing}, " +
            //          $"sims.timeslot.count: {appointmentCount.Queued}, " +
            //          $"Timeslots inserted: {appointmentCount.Inserted}, " +
            //          $"Timeslots deleted: {appointmentCount.Deleted}");
            #endregion

            return inventoryList;
        }

        private bool disposed = false;
        // Protected implementation of Dispose pattern.
        protected virtual void Dispose(bool disposing)
        {
            if (disposed)
                return;

            if (disposing)
            {
                // Free any other managed objects here.
                //
            }

            // Free any unmanaged objects here.
            //
            disposed = true;
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }
    }
}
