﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace HealthCare.Fortis.DataProviders
{
    public class Timeslot
    {
        public string InventoryId { get; set; }
        public string Pwid { get; set; }
        public string AppointmentDateTime { get; set; }
        public string AppointmentDateTimeUtc { get; set; }
    }
}
