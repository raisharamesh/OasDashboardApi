﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using HealthCare.Apollo.DataProviders;
using HealthCare.Common;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;

namespace HealthCare.Apollo.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TimeslotsController : ControllerBase
    {
       
        // GET api/values/5
        [HttpGet("{Pwid}")]
        public async Task<IActionResult> Get(string Pwid, DateTime? startDate = null, DateTime? endDate = null)
        {
            IList timslots = null;
            try
            {
                using (var timeslotDataService = new TimeslotDataService())
                {
                    timslots = await timeslotDataService.GetProviderInventory(Pwid, startDate, endDate);
                }
                return Ok(timslots);
            }
            catch (KeyNotFoundException ex)
            {
                //_logger.Error(ex.Message, ex);
                return NotFound(ex.Message);
            }
            catch (Exception ex)
            {

                var protocol = JsonConvert.DeserializeObject<TimeSlot>("{}");
                //_logger.Error(ex.Message, ex);
                if (ex.Message.Contains("key does not exist"))
                    return Ok(new TimeSlot());
                return BadRequest($"Some exception occurred. {ex.Message}");

            }
        }
    }
}