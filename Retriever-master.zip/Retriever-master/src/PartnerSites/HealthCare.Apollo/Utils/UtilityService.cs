﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Threading.Tasks;

namespace HealthCare.Apollo.Utils
{
    public class UtilityService
    {
        public static int _windowDays = 30;
        public static void WriteToJsonFile<T>(string filePath, T objectToWrite, bool append = false) where T : new()
        {
            System.IO.TextWriter writer = null;
            try
            {
                var contentsToWriteToFile = Newtonsoft.Json.JsonConvert.SerializeObject(objectToWrite);
                writer = new System.IO.StreamWriter(filePath, append);
                writer.Write(contentsToWriteToFile);
            }
            finally
            {
                if (writer != null)
                    writer.Close();
            }
        }
        public static int CalculateWindowDays(DateTime startDate, DateTime endDate)
        {
            return CalculateWindowDays(startDate, endDate, _windowDays);
        }

        public static int CalculateWindowDays(DateTime startDate, DateTime endDate, int defaultNumOfDays)
        {
            var totalDays = (endDate.Date - startDate.Date).TotalDays;

            return totalDays < 0 ?
                defaultNumOfDays : Convert.ToInt32(totalDays);
        }
        public static async Task<T> ReadFromJsonFile<T>(string filePath) where T : new()
        {
            System.IO.TextReader reader = null;
            try
            {
                reader = new System.IO.StreamReader(filePath);
                var fileContents = await reader.ReadToEndAsync();
                return Newtonsoft.Json.JsonConvert.DeserializeObject<T>(fileContents);
            }
            finally
            {
                if (reader != null)
                    reader.Close();
            }
        }

        public static string AssemblyDirectory
        {
            get
            {
                string codeBase = Assembly.GetExecutingAssembly().CodeBase;
                UriBuilder uri = new UriBuilder(codeBase);
                string path = Uri.UnescapeDataString(uri.Path);
                return Path.GetDirectoryName(path);
            }
        }
    }
}
