﻿using System;
using System.Collections.Generic;

namespace HealthCare.Common
{
    public class Inventory
    {
        public string Pwid { get; set; }
        public string StartDate { get; set; }
        public string EndDate { get; set; }
        public string TransactionId { get; set; }
        public IList<TimeSlot> TimeSlotList { get; set; }
        public IList<AppointmentReason> AppointmentReasonlist { get; set; }
        public DateTime CreatedOn { get; set; }
    }

    public class OasWebApiModel
    {
        public IList<TimeSlot> TimeSlotList { get; set; }
        public IList<AppointmentReason> AppointmentReasonList { get; set; }

    }

    public class TimeSlot
    {
        public int Source { get; set; }
        public object InventoryId { get; set; }
        public string Id { get; set; }
        public string PartnerPracticeId { get; set; }
        public string Pwid { get; set; }
        public string OfficeId { get; set; }
        public string PartnerId { get; set; }
        public string PartnerProviderId { get; set; }
        public string PartnerSiteId { get; set; }
        public string PartnerDepartmentId { get; set; }
        public string[] PartnerReasonIds { get; set; }
        public string PartnerReasonIdList { get; set; }
        public DateTime Time { get; set; }
        public DateTime UtcTime { get; set; }
        public int Length { get; set; }
        public string Type { get; set; }
        public string AppointmentCategory { get; set; }
        public bool HasAppointmentReasons { get; set; }
        public string ProviderId { get; set; }
        public string Url { get; set; }
    }

    public class AppointmentReason
    {
        public string ReasonId { get; set; }
        public string Reason { get; set; }
        public string Reasontype { get; set; }
        public string Description { get; set; }
        public int AppointmentCategoryId { get; set; }
        public string AppointmentCategoryName { get; set; }
        public int AppointmentDuration { get; set; }
        public bool IsDefaultReason { get; set; }
        public string ReasonCode { get; set; }
    }
}
