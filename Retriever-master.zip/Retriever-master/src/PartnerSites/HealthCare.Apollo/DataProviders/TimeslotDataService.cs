﻿using HealthCare.Common;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace HealthCare.Apollo.DataProviders
{
    public class TimeslotDataService : IDisposable
    {
        public TimeslotDataService()
        {

        }

        public async Task<List<Inventory>> GetProviderInventory(string pwid, DateTime? startDateTime, DateTime? endDateTime)
        {

            string filepath =  $"{Utils.UtilityService.AssemblyDirectory}\\Data\\ProviderInventory.json";
            var inventoryList =
                await Utils.UtilityService.ReadFromJsonFile<List<Inventory>>(filepath);
            inventoryList= inventoryList.Select(c => { c.Pwid = pwid; return c; }).ToList();
            inventoryList.FirstOrDefault().TimeSlotList= inventoryList.FirstOrDefault().TimeSlotList.Select(c => { c.Pwid = pwid; return c; }).ToList();
            inventoryList.FirstOrDefault().TimeSlotList= inventoryList.FirstOrDefault().TimeSlotList.Select(c => { c.ProviderId = pwid; return c; }).ToList();
            var windowDateTime = startDateTime.HasValue ? startDateTime : DateTime.Now;
            var windowDays = Utils.UtilityService.CalculateWindowDays(windowDateTime.Value, endDateTime.GetValueOrDefault());
            endDateTime = endDateTime ?? windowDateTime.Value.AddDays(windowDays);

            return inventoryList;
        }

        private bool disposed = false;
        // Protected implementation of Dispose pattern.
        protected virtual void Dispose(bool disposing)
        {
            if (disposed)
                return;

            if (disposing)
            {
                // Free any other managed objects here.
                //
            }

            // Free any unmanaged objects here.
            //
            disposed = true;
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }
    }
}
