﻿using Amazon.SQS;
using Amazon.SQS.Model;
using HealthCareServices.Partners.Common;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace HealthCare.InventoryRetriever
{
    public class LoadQueue : ILoadQueue
    {
        readonly IAmazonSQS queue;
        readonly string queueUrl;

        public LoadQueue(IAmazonSQS queue, string queueUrl)
        {
           this.queue = queue;
            this.queueUrl = queueUrl;
        }

        public Message GetFirst()
        {
            var request = new ReceiveMessageRequest
            {
                WaitTimeSeconds = 20,
                MaxNumberOfMessages = 1,
                QueueUrl = queueUrl
            };

            var message = queue
                .ReceiveMessageAsync(request)
                .GetAwaiter()
                .GetResult()
                .Messages
                .FirstOrDefault();

            if (message == null)
                return null;

            return message;
        }

        public async Task<Message[]> Get(int maxNumOfMsgs = 1)
        {
            var request = new ReceiveMessageRequest
            {
                WaitTimeSeconds = 20,
                MaxNumberOfMessages = maxNumOfMsgs,
                QueueUrl = queueUrl
            };

            var messages = queue
                .ReceiveMessageAsync(request)
                .GetAwaiter()
                .GetResult()
                .Messages
                .ToList();

            if (messages == null)
                return null;
            return messages.ToArray();
        }

        public void Delete(Message msg)
        {
            var deleteRequest = new DeleteMessageRequest
            {
                ReceiptHandle = msg.ReceiptHandle,
                QueueUrl = queueUrl
            };

            queue
                .DeleteMessageAsync(deleteRequest)
                .GetAwaiter()
                .GetResult();
        }

        public void Delete(Message[] messages)
        {
            foreach (var msg in messages)
                Delete(msg);
        }

        public void Send(Inventory inventory)
        {
            var request = new SendMessageRequest
            {
                QueueUrl = queueUrl,
                MessageBody = inventory.ToJson()
            };

            queue
                .SendMessageAsync(request)
                .GetAwaiter() 
                .GetResult();
        }
    }
}
