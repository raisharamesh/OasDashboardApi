﻿using System;
using System.Collections.Generic;
using System.Net.Http.Headers;
using HealthCareServices.Partners.Common;
using HealthCareServices.Partners.Apollo;
using HealthCareServices.Partners.Fortis;
using HealthCare.InventoryRetriever;
using Amazon.SQS;
using Amazon;

namespace Microsoft.Extensions.DependencyInjection
{
    public static class DependencyInjectionExtensions
    {
        public static IServiceCollection AddPatnerHttpClients(this IServiceCollection service, AppSettings appSettings)
        {
            service
                .AddHttpClient<IApolloPost, ApolloPost>(c =>
                {
                    c.BaseAddress = new Uri(appSettings.PartnerServiceUrl["APOLLO"]);
                    c.DefaultRequestHeaders.Accept
                        .Add(new MediaTypeWithQualityHeaderValue("application/json"));
                });

            service
              .AddHttpClient<IFortisPost, FortisPost>(c =>
              {
                  c.BaseAddress = new Uri(appSettings.PartnerServiceUrl["FORTIS"]);
                  c.DefaultRequestHeaders.Accept
                      .Add(new MediaTypeWithQualityHeaderValue("application/json"));
              });

            return service;
        }

        public static IServiceCollection AddPartnerServices(this IServiceCollection services, AppSettings settings)
        {
            services.AddScoped<Retriever>();
            services.AddScoped<IServiceLocator, ServiceLocator>();
            services.AddScoped<ApolloPartnerService>();
            services.AddScoped<FortisPartnerService>();

            var sqsClient = new AmazonSQSClient(settings.AwsCreds.AccessKeyId,
                    settings.AwsCreds.SecretKey,
                    RegionEndpoint.GetBySystemName(settings.AwsCreds.RegionName));

            services.AddScoped<ILoadQueue>(x => new LoadQueue(sqsClient, settings.LoadQueue.Url));

            services.AddScoped<Func<string, IPartnerService>>(
                ServiceProvider => key =>
                {
                    switch (key)
                    {
                        case "APOLLO":
                            return ServiceProvider.GetService<ApolloPartnerService>();
                        case "FORTIS":
                            return ServiceProvider.GetService<FortisPartnerService>();
                        default:
                            throw new KeyNotFoundException();
                    }
                });

            return services;
        }

    }
}