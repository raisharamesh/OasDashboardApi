using Amazon.SQS;
using Amazon.SQS.Model;
using Microsoft.Extensions.Logging;
using System.Collections.Generic;
using System.Linq;

namespace HealthCare.InventoryRetriever
{
    public class SqsRefreshQueue : IRefreshQueue
    {
        private IAmazonSQS client;
        private ILogger logger;
        private string queueUrl;

        public SqsRefreshQueue(IAmazonSQS client, string queueUrl)
        {
            this.client = client;
            this.queueUrl = queueUrl;
        }

        public Message Get()
        {
            var request = new ReceiveMessageRequest {
                WaitTimeSeconds = 20,
                MaxNumberOfMessages = 1,
                QueueUrl = queueUrl
            };

            return client
                .ReceiveMessageAsync(request)
                .GetAwaiter()
                .GetResult()
                .Messages
                .FirstOrDefault();
        }

        public void Delete(Message msg)
        {
            var deleteRequest = new DeleteMessageRequest {
                ReceiptHandle = msg.ReceiptHandle,
                QueueUrl = queueUrl
            };

            client
                .DeleteMessageAsync(deleteRequest)
                .GetAwaiter()
                .GetResult();
        }

    }
}