﻿using System;
using System.Collections.Generic;
using System.Text;

namespace HealthCare.InventoryRetriever
{
    public class InventoryRefreshRequest
    {
        public string Pwid { get; set; }
        public string StartDate { get; set; }
        public string EndDate { get; set; }
        public string TransactionId { get; set; } 
        public string PartnerCode { get; set; }
    }
}
