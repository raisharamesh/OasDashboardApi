﻿using Amazon.Lambda.Core;
using Amazon.Lambda.SQSEvents;
using HealthCareServices.Partners.Common;
using System;
using System.Diagnostics;
using System.Threading.Tasks;

namespace HealthCare.InventoryRetriever
{
    public class Retriever
    {
        ILoadQueue outgoingQueue;
        private readonly IServiceLocator _serviceLocator;

        public Retriever(
            ILoadQueue loadQueue,
            IServiceLocator serviceLocator)
        {
            outgoingQueue = loadQueue;
            _serviceLocator = serviceLocator;
        }

        public async Task RetrieveInventory(SQSEvent.SQSMessage message, ILambdaContext context)
        {
            if (message == null)
                return;

            var refreshRequest = message
                .Body
                .To<InventoryRefreshRequest>();

            if (refreshRequest == null)
                return;

            var logger = context.Logger;
            void write(string msg) => logger.LogLine(msg);

            write("recieved");
           
        var watch = new Stopwatch();
            watch.Start();
            IPartnerService partnerService = _serviceLocator.LocatePartner(refreshRequest.PartnerCode.ToUpper());
            var timeslotRequest = new TimeSlotsRequest() {
                PartnerId = refreshRequest.PartnerCode,
                PartnerProviderId = refreshRequest.Pwid,
                StartDate = Convert.ToDateTime(refreshRequest.StartDate),
                EndDate = Convert.ToDateTime(refreshRequest.EndDate)
            };
            var inventory =  await partnerService.GetTimeSlots(timeslotRequest);
            watch.Stop();
            if (inventory == null)
            {
                //message will not be deleted here
                write("failed to find inventory");
                return;
            }

            write($"{inventory.TimeSlotList.Count} timeslots retrieved taking {watch.ElapsedMilliseconds} ms");

            outgoingQueue.Send(inventory);

            write($"timeslots sent to be loaded"); 
        }
    }
}
