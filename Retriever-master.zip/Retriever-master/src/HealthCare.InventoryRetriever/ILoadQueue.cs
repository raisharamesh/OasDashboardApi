﻿using Amazon.SQS.Model;
using HealthCareServices.Partners.Common;
using System.Threading.Tasks;

namespace HealthCare.InventoryRetriever
{
    public interface ILoadQueue
    {
        Message GetFirst();
        Task<Message[]> Get(int maxNumOfMsgs = 1); 
        void Delete(Message msg);
        void Delete(Message[] messages);
        void Send(Inventory inventory);
    }
}
