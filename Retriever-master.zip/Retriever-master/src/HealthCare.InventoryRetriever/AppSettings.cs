﻿using System.Collections.Generic;
using Microsoft.Extensions.Configuration;
using System.IO;
using System.Reflection;

namespace HealthCare.InventoryRetriever
{
    public class AppSettings
    {
        public AwsCredential AwsCreds { get; set; }
        public LoadQueueConfiguration LoadQueue { get; set; }
        public RefreshQueueConfiguration RefreshQueue { get; set; }
        public Dictionary<string, string> PartnerServiceUrl { get; set; }

        public static AppSettings GetSettings(params string[] args)
        {
            return new ConfigurationBuilder()
                .SetBasePath(Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location))
                .AddJsonFile("appsettings.json", optional: true, reloadOnChange: true)
                .AddJsonFile("appsettings.{env.EnvironmentName}.json", optional: true, reloadOnChange: true)
                .AddEnvironmentVariables()
                .AddCommandLine(args)
                .Build()
                .Get<AppSettings>();
        }
    }
    public class AwsCredential
    {
        public string AccessKeyId { get; set; }
        public string SecretKey { get; set; }
        public string RegionName { get; set; }
    }

    public class LoadQueueConfiguration
    {
        public string Url { get; set; }
        public int BatchReadCount { get; set; }
    }

    public class RefreshQueueConfiguration
    {
        public string Url { get; set; }
    }
}
