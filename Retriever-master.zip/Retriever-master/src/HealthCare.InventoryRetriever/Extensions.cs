﻿using HealthCareServices.Partners.Common;
using Newtonsoft.Json;
using System.Collections.Generic;


namespace HealthCare.InventoryRetriever
{
    public static class StringExtensions
    {
        public static T To<T>(this string value)
        {
            return JsonConvert
                .DeserializeObject<T>(value);
        }
    }

    public static class GenericExtensions
    {
        public static string Concat(this IEnumerable<string> values)
        {
            return string.Concat(values);
        }

        public static string ToJson(this Inventory inventory)
        {
            if (inventory == null)
                return null;

            return JsonConvert.SerializeObject(inventory);
        }
        public static string ToJson(this ITimeSlotsAndReasons inventory)
        {
            if (inventory == null)
                return null;

            return JsonConvert.SerializeObject(inventory);
        }

    }

}
