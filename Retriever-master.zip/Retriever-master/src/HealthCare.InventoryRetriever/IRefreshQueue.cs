using Amazon.SQS.Model;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace HealthCare.InventoryRetriever
{
    public interface IRefreshQueue
    {
        Message Get();
        void Delete(Message msg);
    }
}