﻿using HealthCareServices.Partners.Apollo;
using HealthCareServices.Partners.Common;
using HealthCareServices.Partners.Fortis;
using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Http;

namespace HealthCare.InventoryRetriever
{
    public interface IRepositoryResolver
    {
        IPartnerService GetPartnerServiceByName(string name);
    }

    public class RepositoryResolver : IRepositoryResolver
    {
        private readonly IServiceProvider _serviceProvider;
        public RepositoryResolver(IServiceProvider serviceProvider)
        {
            _serviceProvider = serviceProvider;
        }
        public IPartnerService GetPartnerServiceByName(string name)
        {

            switch (name.ToLower())
            {
                case "apollo":
                    return _serviceProvider.GetService<ApolloPartnerService>();
                case "fortis":
                    return _serviceProvider.GetService<FortisPartnerService>();
                default: 
                    throw new KeyNotFoundException();
            }

        }
    }
}