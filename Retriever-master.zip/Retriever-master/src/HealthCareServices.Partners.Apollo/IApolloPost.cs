﻿using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Text;
using HealthCareServices.Partners.Common;

namespace HealthCareServices.Partners.Apollo
{
    public interface IApolloPost : IJustPost
    { }

    public class ApolloPost : JustPost, IApolloPost
    {
        public ApolloPost(HttpClient client)
            : base(client)
        { }
    }
}
