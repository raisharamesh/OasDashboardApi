﻿using AutoMapper;
using HealthCareServices.Partners.Common;

namespace HealthCareServices.Partners.Apollo
{
    class TimeslotMappingProfile : Profile
    {
        public TimeslotMappingProfile()
        {
            CreateMap<ApolloSlotsAndReason, TimeSlotsAndReasons>()
               .ForMember(patient => patient.TimeSlotList, o => o.MapFrom(d => d.TimeSlotList))
               .ForMember(patient => patient.AppointmentReasonList, o => o.MapFrom(d => d.AppointmentReasonlist))
               .ForAllOtherMembers(patient => patient.Ignore());

            CreateMap<ApolloTimeSlot, TimeSlot>()
              .ForMember(slot => slot.Id, o => o.MapFrom(d => d.Id))
              .ForMember(slot => slot.Pwid, o => o.MapFrom(d => d.Pwid))
              .ForMember(slot => slot.OfficeId, o => o.MapFrom(d => d.OfficeId))
              .ForMember(slot => slot.PartnerId, o => o.MapFrom(d => d.PartnerId))
              .ForMember(slot => slot.PartnerProviderId, o => o.MapFrom(d => d.PartnerProviderId))
              .ForMember(slot => slot.PartnerSiteId, o => o.MapFrom(d => d.PartnerSiteId))
              .ForMember(slot => slot.PartnerDepartmentId, o => o.MapFrom(d => d.PartnerDepartmentId))
              .ForMember(slot => slot.PartnerReasonIdList, o => o.MapFrom(d => d.PartnerReasonIdList))
              .ForMember(slot => slot.PartnerReasonIds, o => o.MapFrom(d => d.PartnerReasonIds))
              .ForMember(slot => slot.Time, o => o.MapFrom(d => d.Time))
              .ForMember(slot => slot.UtcTime, o => o.MapFrom(d => d.UtcTime))
              .ForMember(slot => slot.Type, o => o.MapFrom(d => d.Type))
              .ForMember(slot => slot.AppointmentCategory, o => o.MapFrom(d => d.AppointmentCategory))
              .ForMember(slot => slot.HasAppointmentReasons, o => o.MapFrom(d => d.HasAppointmentReasons))
              .ForMember(slot => slot.ProviderId, o => o.MapFrom(d => d.ProviderId))
              .ForAllOtherMembers(patient => patient.Ignore());

            CreateMap<ApolloAppointmentReason, AppointmentReason>()
              .ForMember(patient => patient.ReasonId, o => o.MapFrom(d => d.ReasonId))
              .ForMember(patient => patient.Reason, o => o.MapFrom(d => d.Reason))
              .ForMember(patient => patient.Reasontype, o => o.MapFrom(d => d.Reasontype))
              .ForMember(patient => patient.Description, o => o.MapFrom(d => d.Description))
              .ForMember(patient => patient.AppointmentCategoryId, o => o.MapFrom(d => d.AppointmentCategoryId))
              .ForMember(patient => patient.AppointmentCategoryName, o => o.MapFrom(d => d.AppointmentCategoryName))
              .ForMember(patient => patient.AppointmentDuration, o => o.MapFrom(d => d.AppointmentDuration))
              .ForMember(patient => patient.ReasonCode, o => o.MapFrom(d => d.ReasonCode))
              .ForAllOtherMembers(patient => patient.Ignore());
        }

        public override string ProfileName
        {
            get { return "TimeslotProfile"; }
        }

    }
}