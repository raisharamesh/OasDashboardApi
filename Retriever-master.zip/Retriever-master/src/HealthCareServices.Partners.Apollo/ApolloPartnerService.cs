﻿using AutoMapper;
using HealthCareServices.Partners.Common;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;

namespace HealthCareServices.Partners.Apollo
{
    public class ApolloPartnerService : IPartnerService
    {
        private int _windowDays = 30;
        private string _apolloServiceUrl = null;
        private IApolloPost _apolloPost;
        private static IMapper _mapper;
        public ApolloPartnerService(IApolloPost apolloPost)
        {
            _apolloPost = apolloPost;
            _apolloServiceUrl = _apolloPost.Client.BaseAddress.ToString();
        }
        static ApolloPartnerService()
        {
            var config = new MapperConfiguration(cfg =>
            {
                cfg.AddProfile<TimeslotMappingProfile>();
            });
            _mapper = config.CreateMapper();

        }
        public static string Name { get { return "Apollo"; } }

        public Task<string> BookAppointment()
        {
            throw new NotImplementedException();
        }

        public Task<bool> CancelAppointment(string appointmentId)
        {
            throw new NotImplementedException();
        }

        public async Task<Inventory> GetTimeSlots(ITimeSlotsRequest timeSlotsRequest)
        {
            var inventory = new Inventory();
            timeSlotsRequest.StartDate = (null == timeSlotsRequest.StartDate) ? DateTime.UtcNow : timeSlotsRequest.StartDate;

            timeSlotsRequest.NumberOfDays = timeSlotsRequest.NumberOfDays == null
                    || timeSlotsRequest.NumberOfDays == -1 ? _windowDays : (int)timeSlotsRequest.NumberOfDays;

            var filterEndDate = ((DateTime)timeSlotsRequest.StartDate).AddDays((int)timeSlotsRequest.NumberOfDays);

            var endDate = timeSlotsRequest.EndDate != null ?
                      (timeSlotsRequest.EndDate.Value.AddHours(23).AddMinutes(59).AddSeconds(59))
                      : (timeSlotsRequest.StartDate.Value.AddDays(timeSlotsRequest.NumberOfDays == null
                      || timeSlotsRequest.NumberOfDays == -1 ?
                      _windowDays : (int)timeSlotsRequest.NumberOfDays)).Date.AddHours(23).AddMinutes(59).AddSeconds(59);
            //Update the request end date if time is not specified in the request 
            timeSlotsRequest.EndDate = endDate;
            var ApolloTimeSlotsAndReasons = await PhysicianAppointmentSearch(
                timeSlotsRequest.PartnerProviderId,
                timeSlotsRequest.StartDate.Value,
                timeSlotsRequest.EndDate.Value);
            inventory.Pwid = timeSlotsRequest.PartnerProviderId;
            inventory.StartDate = timeSlotsRequest.StartDate.Value.ToString("MM/dd/yyyy hh:mm:ss tt");
            inventory.EndDate = endDate.ToString("MM/dd/yyyy hh:mm:ss tt");
            inventory.AppointmentReasonlist = ApolloTimeSlotsAndReasons.AppointmentReasonList;
            inventory.TimeSlotList = ApolloTimeSlotsAndReasons.TimeSlotList;

            return inventory;
        }

        private async Task<ITimeSlotsAndReasons> PhysicianAppointmentSearch(string providerId, DateTime startDate, DateTime endDate)
        {
            string url = $"{_apolloServiceUrl}/Timeslots/{providerId}?startDate={startDate}&endDate={endDate}";
            Debug.WriteLine($"Service URL: {url}");
            Console.WriteLine($"Service URL: {url}");
            var apolloAppointmentSearchResponse = await _apolloPost
              .Get<List<ApolloSlotsAndReason>>(url);
            var timeSlotsAndReasons = _mapper.Map<TimeSlotsAndReasons>(apolloAppointmentSearchResponse.FirstOrDefault());
            Debug.WriteLine($"Timeslots retrieved: {timeSlotsAndReasons.TimeSlotList.Count()}");
            Console.WriteLine($"Timeslots retrieved: {timeSlotsAndReasons.TimeSlotList.Count()}");

            return timeSlotsAndReasons;
        }
    }
}
