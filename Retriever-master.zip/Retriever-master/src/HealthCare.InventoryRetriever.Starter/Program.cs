﻿using HealthCare.InventoryRetriever.Lambda;
using System;

namespace HealthCare.InventoryRetriever.Starter
{
    class Program
    {
        static void Main(string[] args)
        {
            new Function().Listen().GetAwaiter().GetResult();
        }
    }
}
