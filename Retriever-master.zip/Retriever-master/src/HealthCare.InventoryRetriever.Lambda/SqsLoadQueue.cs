﻿using Amazon.SQS;

namespace HealthCare.InventoryRetriever.Lambda
{
    internal class SqsLoadQueue
    {
        private AmazonSQSClient sqsClient;
        private string url;
        //private object s3Client;
        //private object bucketName;
        //private object bucketSubFolder;

        public SqsLoadQueue(AmazonSQSClient sqsClient, string url)
        {
            this.sqsClient = sqsClient;
            this.url = url;
            //this.s3Client = s3Client;
            //this.bucketName = bucketName;
            //this.bucketSubFolder = bucketSubFolder;
        }
    }
}