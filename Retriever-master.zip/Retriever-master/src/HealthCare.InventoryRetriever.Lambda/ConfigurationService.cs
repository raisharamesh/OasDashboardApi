﻿
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using static HealthCare.InventoryRetriever.Lambda.Constants;

namespace HealthCare.InventoryRetriever.Lambda
{
    public interface IConfigurationService
    {
        IConfiguration GetConfiguration();
    }
    public class ConfigurationService : IConfigurationService
    {
        public IEnvironmentService EnvService { get; }

        public ConfigurationService(IEnvironmentService envService)
        {
            EnvService = envService;
        }

        public IConfiguration GetConfiguration()
        {
            return new ConfigurationBuilder()
                .SetBasePath(Directory.GetCurrentDirectory())
                .AddJsonFile("appsettings.json", optional: false, reloadOnChange: true)
                .AddJsonFile($"appsettings.{EnvService.EnvironmentName}.json", optional: true)
                .AddEnvironmentVariables()
                .Build();
        }
    }
    public interface IEnvironmentService
    {
        string EnvironmentName { get; set; }
    }
    public class EnvironmentService : IEnvironmentService
    {
        public EnvironmentService()
        {
            EnvironmentName = Environment.GetEnvironmentVariable(EnvironmentVariables.AspnetCoreEnvironment)
                ?? Environments.Production;
        }

        public string EnvironmentName { get; set; }
    }

    public static class Constants
    {
        public static class EnvironmentVariables
        {
            public const string AspnetCoreEnvironment = "ASPNETCORE_ENVIRONMENT";
        }

        public static class Environments
        {
            public const string Production = "Testing";
        }
        public static class AwsCreds
        {
            public const string AccessKeyId = "";
            public const string SecretKey = "";
            public const string RegionName = "";
        }
        public static class LoadQueue
        {
            public const string Url = "";
            public const int BatchReadCount = 1;
        }
        public static class RefreshQueue
        {
            public const string Url = "";
        }
    }
}
