﻿using HealthCareServices.Partners.Common;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using HealthCareServices.Partners.Common;
using HealthCareServices.Partners.Apollo;
using System.Linq;
using System.Diagnostics;

namespace HealthCareServices.Partners.Fortis
{
    public class FortisPartnerService : IPartnerService
    {
        private int _windowDays = 30;
        private string _fortisServiceUrl = null;
        private IFortisPost _fortisPost;
        public FortisPartnerService(IFortisPost fortisPost)
        {
            _fortisPost = fortisPost;
            _fortisServiceUrl = _fortisPost.Client.BaseAddress.ToString();
        }
        public Task<string> BookAppointment()
        {
            throw new NotImplementedException();
        }

        public Task<bool> CancelAppointment(string appointmentId)
        {
            throw new NotImplementedException();
        }

        public async Task<Inventory> GetTimeSlots(ITimeSlotsRequest timeSlotsRequest)
        {
            var appointmentList = new List<TimeSlot>();
            var inventory = new Inventory();
            timeSlotsRequest.StartDate = (null == timeSlotsRequest.StartDate) ? DateTime.UtcNow : timeSlotsRequest.StartDate;

            timeSlotsRequest.NumberOfDays = timeSlotsRequest.NumberOfDays == null
                    || timeSlotsRequest.NumberOfDays == -1 ? _windowDays : (int)timeSlotsRequest.NumberOfDays;

            var filterEndDate = ((DateTime)timeSlotsRequest.StartDate).AddDays((int)timeSlotsRequest.NumberOfDays);

            var endDate = timeSlotsRequest.EndDate != null ?
                      (timeSlotsRequest.EndDate.Value.AddHours(23).AddMinutes(59).AddSeconds(59))
                      : (timeSlotsRequest.StartDate.Value.AddDays(timeSlotsRequest.NumberOfDays == null
                      || timeSlotsRequest.NumberOfDays == -1 ?
                      _windowDays : (int)timeSlotsRequest.NumberOfDays)).Date.AddHours(23).AddMinutes(59).AddSeconds(59);
            //Update the request end date if time is not specified in the request 
            timeSlotsRequest.EndDate = endDate;
            var fortisTimeSlotsAndReasons = await PhysicianAppointmentSearch(
                timeSlotsRequest.PartnerProviderId,
                timeSlotsRequest.StartDate.Value,
                timeSlotsRequest.EndDate.Value);

            inventory = MapToInventory(fortisTimeSlotsAndReasons, timeSlotsRequest.StartDate, endDate);

            return inventory;
        }

        private Inventory MapToInventory(List<FortisTimeslot> fortisTimeSlotsAndReasons, DateTime? startDate, DateTime endDate)
        {

            var timeSlots = new List<TimeSlot>();
            foreach(var item in fortisTimeSlotsAndReasons)
            {
                var slotDetails = item.InventoryId.Split('_');
                var timeSlot = new TimeSlot() {
                    Pwid = slotDetails[0],
                    Time = Convert.ToDateTime(slotDetails[1]),
                    PartnerId = slotDetails[2],
                    OfficeId = slotDetails[3],
                    PartnerProviderId = slotDetails[4],
                    PartnerSiteId = slotDetails[5],
                    PartnerDepartmentId = slotDetails[6],
                    Id = slotDetails[7],
                    Length = Convert.ToInt32(slotDetails[8]),
                    AppointmentCategory = slotDetails[12],
                    PartnerReasonIdList = slotDetails[11]
                };
                timeSlots.Add(timeSlot);
            }

            var appointmentReasons = timeSlots.GroupBy(x => x.PartnerReasonIdList)
                .Select(groupedTimeslots => new AppointmentReason
                {
                    ReasonId = groupedTimeslots.Key.Split('|')[0],
                    ReasonCode = groupedTimeslots.Key.Split('|')[0],
                    Description = groupedTimeslots.Key.Split('|')[1],
                    Reason = groupedTimeslots.Key.Split('|')[1],
                    AppointmentCategoryName = groupedTimeslots.FirstOrDefault().AppointmentCategory,
                })
                .ToList();
            
            return new Inventory() {
                Pwid = timeSlots.FirstOrDefault()?.Pwid,
                StartDate = startDate?.ToString("MM/dd/yyyy hh:mm:ss tt"),
                EndDate = endDate.ToString("MM/dd/yyyy hh:mm:ss tt"),
                TimeSlotList = timeSlots,
                AppointmentReasonlist = appointmentReasons,
                TransactionId = Guid.NewGuid().ToString()
            };
        }

        private async Task<List<FortisTimeslot>> PhysicianAppointmentSearch(string providerId, DateTime startDate, DateTime endDate)
        {
            string url = $"{_fortisServiceUrl}/Timeslots/{providerId}?startDate={startDate}&endDate={endDate}";
            Console.WriteLine($"Service URL: {url}");
            Debug.WriteLine($"Service URL: {url}");
            var fortisAppointmentSearchResponse  = await _fortisPost
                .Get<List<FortisTimeslot>>(url);
            Console.WriteLine($"Timeslots retrieved: {fortisAppointmentSearchResponse.Count()}");
            Debug.WriteLine($"Timeslots retrieved: {fortisAppointmentSearchResponse.Count()}");
            return fortisAppointmentSearchResponse;
        }
    }
}
