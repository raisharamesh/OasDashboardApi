﻿using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Text;
using HealthCareServices.Partners.Common;

namespace HealthCareServices.Partners.Apollo
{
    public interface IFortisPost : IJustPost
    { }

    public class FortisPost : JustPost, IFortisPost
    {
        public FortisPost(HttpClient client)
            : base(client)
        { }
    }
}
