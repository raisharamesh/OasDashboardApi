﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace HealthCareServices.Partners.Fortis
{
    public class FortisTimeslot
    {
        public string InventoryId { get; set; }
        public string Pwid { get; set; }
        public string AppointmentDateTime { get; set; }
        public string AppointmentDateTimeUtc { get; set; }
    }
}
