using Newtonsoft.Json;
using System.Web;

namespace System    // using the same namespace of the object we're extending
{
    public static class Extensions{
        public static T To<T>(this string value)
        {
            return JsonConvert
                .DeserializeObject<T>(value);
        }
   
        public static DateTime ToDateTime(this string value)
        {
            return DateTime.Parse(value);
        }
        

    }

}