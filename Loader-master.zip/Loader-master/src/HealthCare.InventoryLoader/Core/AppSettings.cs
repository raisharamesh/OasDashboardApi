﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace HealthCare.InventoryLoader
{
    public class AppSettings
    {
        public AwsCredentials AwsCreds { get; set; }
        public LoadQueueConfiguration LoadQueue { get; set; }
    }

    public class AwsCredentials
    {
        public string AccessKeyId { get; set; }
        public string SecretKey { get; set; }
        public string RegionName { get; set; }
    }

    public class LoadQueueConfiguration
    {
        public string Url { get; set; }
    }

   

    public static class AppSettingsExtensions
    {
        public static AppSettings UseAwsExecutionRole(this AppSettings settings)
        {
            if (settings.AwsCreds == null)
                settings.AwsCreds = new AwsCredentials();
            return settings;
        }

        public static List<string> GetMissingSettings(this Object settings)
        {
            var missingSettings = settings
                .GetType()
                .GetProperties()
                .Where(x => x.PropertyType == typeof(string))
                .Where(x => string.IsNullOrWhiteSpace((string)x.GetValue(settings)))
                .Select(x => x.Name)
                .ToList();

            var nestedObjectProps = settings
                .GetType()
                .GetProperties()
                .Where(x => x.PropertyType != typeof(string))
                .Where(x => x.PropertyType.IsClass);

            var nestedNullObjs = nestedObjectProps
                .Where(x => x.GetValue(settings) == null)
                .Select(x => x.Name)
                .ToList();

            var nestedMissingSettings = nestedObjectProps
                .Where(x => x.GetValue(settings) != null)
                .SelectMany(x => {
                    return
                        GetMissingSettings(x.GetValue(settings))
                            .Select(s => $"{x.Name}.{s}");
                 })
                .ToList();

            missingSettings.AddRange(nestedNullObjs);
            missingSettings.AddRange(nestedMissingSettings);

            return missingSettings;
        }

        public static AppSettings Verify(this AppSettings settings)
        {
            var missingSettings = settings.GetMissingSettings();
            if (missingSettings == null || missingSettings.Any())
                throw new ApplicationException("The following settings are missing: " + string.Join(", ", missingSettings));

            return settings;
        }
    }
}
