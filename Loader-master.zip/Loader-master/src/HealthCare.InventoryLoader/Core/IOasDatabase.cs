using HealthCare.InventoryLoader;
using HealthCare.InventoryLoader.Queue;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace HealthCare.InventoryLoader
{
    public interface IOasDatabase
    {
        Task<bool> Update(List<Inventory> inventory);
    }
}