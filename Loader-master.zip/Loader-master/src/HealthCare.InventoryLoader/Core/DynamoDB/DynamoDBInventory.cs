﻿using Amazon.DynamoDBv2.DataModel;

namespace HealthCare.InventoryLoader.DynamoDB
{
    [DynamoDBTable("ProviderSchedule")]
    public class DynamoDbInventory
    {
        [DynamoDBHashKey]
        public string InventoryId { get; set; }
        [DynamoDBRangeKey]
        public string Pwid { get; set; }
        [DynamoDBProperty]
        public string AppointmentDateTime { get; set; }
        //[DynamoDBProperty]
        //public string AppointmentDateTimeUtc { get; set; }
    }
}
