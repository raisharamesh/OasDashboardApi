﻿using HealthCare.InventoryLoader;
using HealthCare.InventoryLoader.Queue;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Threading.Tasks;

namespace HealthCare.InventoryLoader.DynamoDB
{
    public class DynamoDbDatabase : IOasDatabase
    {
        private IDynamoDbInventoryService _dynamoDbInventoryService;

        public AppLogger Logger { get; set; }

        public DynamoDbDatabase(IDynamoDbInventoryService dynamoDbInventoryService, ILogger logger = null)
        {
            _dynamoDbInventoryService = dynamoDbInventoryService;

            if (logger != null)
                Logger = new AppLogger(logger);
        }

        public async Task<bool> Update(List<Inventory> inventoryList)
        {
            await LogTime(
                "Upsert Inventory",
                () => _dynamoDbInventoryService.Upsert(inventoryList)
            );

            return true;
        }

        private async Task<bool> LogTime(string methodDescription, Func<Task<bool>> method)
        {
            var stopWatch = new Stopwatch();
            stopWatch.Start();

            await method();

            stopWatch.Stop();
            Write($"Execution took {stopWatch.ElapsedMilliseconds} ms: {methodDescription}");

            return true;
        }

        protected virtual void Write(string msg)
        {
            Logger?.Write(msg);
        }
    }
}
