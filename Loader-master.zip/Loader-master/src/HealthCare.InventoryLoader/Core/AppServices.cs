﻿using HealthCare.InventoryLoader;
using HealthCare.InventoryLoader.Queue;
using Microsoft.Extensions.Logging;

namespace HealthCare.InventoryLoader
{
    public class AppServices
    {
        public ILogger Logger { get; set; }
        public IOasLoadQueue IncomingQueue { get; set; }
        public IOasDatabase DynamoDb { get; set; }
    }
}
