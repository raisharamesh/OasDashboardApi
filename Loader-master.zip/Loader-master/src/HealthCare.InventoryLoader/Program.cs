﻿using Microsoft.Extensions.Logging;
using System;
using System.Threading.Tasks;

namespace HealthCare.InventoryLoader
{
    public class Program
    {
        public static async Task Main(string[] args)
        {
            var settings = Bootstrapper
                .GetSettings(args)
                .Verify();

            var services = settings.GetServices();

            const int maxNumOfMsgs = 10;
            var incomingQueue = services.IncomingQueue;
            var logger = services.Logger;
            var app = new InventoryLoaderApplication(services);

            while (true)
            {
                logger.LogInformation("listening for messages...");

                try
                {
                    var msgs = await incomingQueue.Get(maxNumOfMsgs);

                    if (msgs == null || msgs.Length == 0)
                        continue;

                    await app.ProcessMessages(msgs);

                    incomingQueue.Delete(msgs);
                }
                catch (Exception ex)
                {
                    logger.LogError(ex, "Sims.OasLoaderException - Main");
                }
            }
        }
    }
}
