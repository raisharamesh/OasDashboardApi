using Amazon;
using Amazon.DynamoDBv2;
using Amazon.DynamoDBv2.DataModel;
using Amazon.Extensions.NETCore.Setup;
using Amazon.Runtime;
using Amazon.SimpleNotificationService;
using Amazon.SQS;
using HealthCare.InventoryLoader;
using HealthCare.InventoryLoader.DynamoDB;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Serilog;
using Serilog.Formatting.Compact;
using System;
using Amazon.S3;
using HealthCare.InventoryLoader.Queue;

namespace HealthCare.InventoryLoader
{
    public static class Bootstrapper
    {
        public static AppSettings GetSettings(params string[] args)
        {
            return new ConfigurationBuilder()
                .SetBasePath(AppDomain.CurrentDomain.BaseDirectory)
                .AddJsonFile("appsettings.json", optional: true, reloadOnChange: true)
                .AddJsonFile("appsettings.{env.EnvironmentName}.json", optional: true, reloadOnChange: true)
                .AddEnvironmentVariables()
                .AddCommandLine(args)
                .Build()
                .Get<AppSettings>();
        }

        public static AppServices GetServices(this AppSettings settings)
        {
            // Configure logging
            Log.Logger = new LoggerConfiguration()
                .MinimumLevel.Debug()
                .Enrich.FromLogContext()
                .WriteTo.RollingFile(pathFormat: "InventoryManager.Loader.log", formatter: new CompactJsonFormatter(), fileSizeLimitBytes: 1000000)
                .WriteTo.Console(formatter: new CompactJsonFormatter())
                .CreateLogger()
                .ForContext("application_name", "Sims.OasLoader");

            var serviceProvider = new ServiceCollection()
                .AddLogging(b => b.AddSerilog())
                .AddDefaultAWSOptions(GetAwsOptions(settings))
                .AddAWSService<IAmazonDynamoDB>()
                .AddTransient<IDynamoDBContext, DynamoDBContext>()
                .AddTransient<IDynamoDbInventoryService>(x => new DynamoDbInventoryService(x.GetService<IDynamoDBContext>(),  x.GetService<ILogger<Program>>()))
                .AddTransient<IOasDatabase, DynamoDbDatabase>()
                .BuildServiceProvider();

            var logger = serviceProvider
                .GetRequiredService<ILogger<Program>>();

            var loadQueue = 
                new AmazonSQSClient(
                    settings.AwsCreds.AccessKeyId,
                    settings.AwsCreds.SecretKey,
                    RegionEndpoint.GetBySystemName(settings.AwsCreds.RegionName));

            var loadQueueBucket = 
                new AmazonS3Client(
                    settings.AwsCreds.AccessKeyId,
                    settings.AwsCreds.SecretKey,
                    RegionEndpoint.GetBySystemName(settings.AwsCreds.RegionName));


            var dynamoDb = serviceProvider.GetRequiredService<IOasDatabase>();

            return new AppServices
            {
                Logger = logger,

                IncomingQueue = new SqsLoadQueue(
                    loadQueue,
                    settings.LoadQueue.Url),
                DynamoDb = dynamoDb,
            };
        }

       

        private static RegionEndpoint GetAwsEndpointByName(string name)
        {
            // default to Virginia.
            var defaultRegionEndpoint = RegionEndpoint.USEast1;
            if (string.IsNullOrWhiteSpace(name)) return defaultRegionEndpoint;

            // fetch the RegionEndpoint by the system name (eg us-east-1 or us-west-2).
            RegionEndpoint regionEndpoint = null;
            try
            {
                regionEndpoint = RegionEndpoint.GetBySystemName(name);
            }
            catch (Exception)
            {
                //TODO: Exeption handling
            }
            return regionEndpoint ?? defaultRegionEndpoint;
        }

        private static AWSOptions GetAwsOptions(AppSettings settings)
        {
            return new AWSOptions()
            {
                Region = GetAwsEndpointByName(settings.AwsCreds.RegionName),
                Credentials = new BasicAWSCredentials(settings.AwsCreds.AccessKeyId, settings.AwsCreds.SecretKey)
            };
        }
    }
}