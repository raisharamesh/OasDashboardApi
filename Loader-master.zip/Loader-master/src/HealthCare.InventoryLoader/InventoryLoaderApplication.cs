using Amazon.SQS.Model;
using HealthCare.InventoryLoader.Queue;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace HealthCare.InventoryLoader
{
    public class InventoryLoaderApplication
    {
        readonly ILogger logger;
        readonly IOasDatabase dynamoDbAccessor;


        public InventoryLoaderApplication(AppServices services)
        {
            logger = services.Logger;
            dynamoDbAccessor = services.DynamoDb;
        }

        public async Task<bool> ProcessMessages(IEnumerable<Message> msgs)
        {
            if (!msgs.Any())
                return true;

            var inventory = msgs.FirstOrDefault().Body.To<Inventory>();
                 //.SelectMany(x => x.Body.To<List<Inventory>>())
                 //.ToList();
            //var inventoryList = ReadFromJsonFile<List<Inventory>>(
            //    @"C:\Temp\inventory\ProviderInventory.json");

            if (null == inventory)
                return true;
            List<Inventory> inventoryList = new List<Inventory>();
            inventoryList.Add(inventory);
            await dynamoDbAccessor.Update(inventoryList);


            return true;
        }

        public static T ReadFromJsonFile<T>(string filePath) where T : new()
        {
            System.IO.TextReader reader = null;
            try
            {
                reader = new System.IO.StreamReader(filePath);
                var fileContents = reader.ReadToEnd();
                return Newtonsoft.Json.JsonConvert.DeserializeObject<T>(fileContents);
            }
            finally
            {
                if (reader != null)
                    reader.Close();
            }
        }

    }
}
