﻿using Newtonsoft.Json;

namespace HealthCare.InventoryLoader.Queue
{
    public static class Extensions
    {
        public static string ToJson(this Inventory inventory)
        {
            if (inventory == null)
                return null;

            return JsonConvert.SerializeObject(inventory);
        }
    }
}
