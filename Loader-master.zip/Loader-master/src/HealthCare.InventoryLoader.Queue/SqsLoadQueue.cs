using Amazon.S3;
using Amazon.S3.Model;
using Amazon.SQS;
using Amazon.SQS.Model;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace HealthCare.InventoryLoader.Queue
{
    public class SqsLoadQueue : IOasLoadQueue
    {
        readonly IAmazonSQS queue;
        readonly IAmazonS3 s3Bucket;
        readonly string queueUrl;
        readonly string s3BucketUrl;
        readonly string subfolder;

        public SqsLoadQueue(IAmazonSQS queue, string queueUrl)
        {
			this.queue = queue;
			this.queueUrl = queueUrl;
        }

        public Message GetFirst()
        {
            var request = new ReceiveMessageRequest
            {
                WaitTimeSeconds = 20,
                MaxNumberOfMessages = 1,
                QueueUrl = queueUrl
            };

            var message = queue
                .ReceiveMessageAsync(request)
                .GetAwaiter()
                .GetResult()
                .Messages
                .FirstOrDefault();

            if (message == null)
                return null;

            message.Body = message.Body; //GetFromS3Bucket(message.Body).GetAwaiter().GetResult();
            return message;
        }

        public async Task<Message[]> Get(int maxNumOfMsgs = 1)
        {
            var request = new ReceiveMessageRequest
            {
                WaitTimeSeconds = 20,
                MaxNumberOfMessages = maxNumOfMsgs,
                QueueUrl = queueUrl
            };

            var messages = queue
                .ReceiveMessageAsync(request)
                .GetAwaiter()
                .GetResult()
                .Messages
                .ToList();

            if (messages == null)
                return null;

            //await Task.Run(() => Parallel.ForEach(messages,  item =>
            //{
            //    item.Body = GetFromS3Bucket(item.Body).GetAwaiter().GetResult();
            //}));
            return messages.ToArray();
        }

        public void Delete(Message msg)
        {
            var deleteRequest = new DeleteMessageRequest {
                ReceiptHandle = msg.ReceiptHandle,
                QueueUrl = queueUrl
            };

            queue
                .DeleteMessageAsync(deleteRequest)
                .GetAwaiter()
                .GetResult();
        }

        public void Delete(Message[] messages)
        {
            foreach (var msg in messages)
                Delete(msg);
        }

        public void Send(Inventory inventory)
        {
            var request = new SendMessageRequest
            {
                QueueUrl = queueUrl,
                MessageBody = inventory.TransactionId
            };

            queue
                .SendMessageAsync(request)
                .GetAwaiter()
                .GetResult();
        }

        public virtual async Task<string> GetFromS3Bucket(string key)
        {
            var request = new GetObjectRequest { Key = subfolder + key, BucketName = s3BucketUrl };
            var response = await s3Bucket.GetObjectAsync(request);

            string responseBody;

            using (StreamReader reader = new StreamReader(response.ResponseStream))
            {
                responseBody = await reader.ReadToEndAsync();
            };
            return responseBody;
        }

        public virtual async Task UploadToS3Bucket(Inventory inventory)
        {
            var putRequest = new PutObjectRequest
            {
                BucketName = s3BucketUrl,
                Key = subfolder + inventory.TransactionId,
                ContentBody = inventory.ToJson(),
                ContentType = "text/plain"
            };

            await s3Bucket.PutObjectAsync(putRequest);
        }

        private string GetSubFolderPath(string subfolder)
        {
            if (string.IsNullOrEmpty(subfolder))
                return string.Empty;

            // Remove trailing or beginning spaces
            subfolder = subfolder.Trim();

            // Add trailing slash if needed
            if (!subfolder.EndsWith('/'))
                return subfolder + "/";

            return subfolder;
        }
    }
}