using Amazon.SQS.Model;
using System.Threading.Tasks;

namespace HealthCare.InventoryLoader.Queue
{
    public interface IOasLoadQueue
    {
        Message GetFirst();
        Task<Message[]> Get(int maxNumOfMsgs = 1);
        void Delete(Message msg);
        void Delete(Message[] messages);
        void Send(Inventory inventory);
        Task<string> GetFromS3Bucket(string key);
    }
}