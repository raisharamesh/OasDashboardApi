using Amazon.Lambda.Core;
using Amazon.Lambda.SQSEvents;
using Amazon.SQS.Model;
using System;
using System.Threading.Tasks;
using System.Linq;
using Microsoft.Extensions.Logging;

// Assembly attribute to enable the Lambda function's JSON input to be converted into a .NET class.
[assembly: LambdaSerializer(typeof(Amazon.Lambda.Serialization.Json.JsonSerializer))]

namespace HealthCare.InventoryLoader.Lambda
{
    public class Function
    {
        readonly AppServices services;
        readonly InventoryLoaderApplication app;

        public Function()
        {
            services = Bootstrapper
                .GetSettings()
                .UseAwsExecutionRole()
                .Verify()
                .GetServices();

            app = new InventoryLoaderApplication(services);
        }

        public async Task FunctionHandler(SQSEvent evnt, ILambdaContext context)
        {
            try
            {
                // Messages from the event contains an id that points to 
                // a file in an s3 bucket where the contents are stored.

                var messages = evnt
                    .Records
                    .Select(x => new Message {
                        MessageId = x.MessageId,
                        Body = x.Body, //GetFromS3(x.Body),
                        ReceiptHandle = x.ReceiptHandle,
                        Attributes = x.Attributes
                    }) 
                    .ToArray();

                Write($"{messages.Length} messages received");

                await app.ProcessMessages(messages);

                Write($"{messages.Length} messages completed");

                await Task.CompletedTask;
            }
            catch (Exception ex)
            {
                Write(ex, "Sims.OasLoader.LambdaException - FunctionHandler");
                throw;
            }
        }

        private string GetFromS3(string key)
        {
            var result = "";
            try
            {
                result = services
                    .IncomingQueue.GetFirst().Body;
                   //.GetFromS3Bucket(key.Trim())
                    //.GetAwaiter()
                    //.GetResult();
            }
            catch (Amazon.S3.AmazonS3Exception)
            {
                throw new ApplicationException($"Could not find '{key}'. Check to see if that file or the S3 bucket exists.");
            }
            return result;
        }

        private void Write(string msg)
        {
            services.Logger.LogInformation(msg);
        }

        private void Write(Exception ex, string msg)
        {
            services.Logger.LogError(ex, msg);
        }
    }
}
